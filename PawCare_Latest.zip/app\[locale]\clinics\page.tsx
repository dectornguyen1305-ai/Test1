import type { Metadata } from "next";
import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { Card } from "@/components/ui/card";
import { createClient, isSupabaseConfigured } from "@/lib/supabase/server";
import { getFallbackClinics } from "@/modules/clinics/mock-clinics";
import {
  MapPin,
  ShieldCheck,
  Star,
  ArrowRight,
  Stethoscope,
} from "lucide-react";
import { BackButton } from "@/components/ui/back-button";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "clinicsSeo" });
  return {
    title: `${t("directoryTitle")} — PawCare`,
    description: t("directoryDescription"),
    alternates: {
      canonical: `/${locale}/clinics`,
      languages: {
        "vi-VN": "/vi/clinics",
        "en-US": "/en/clinics",
        "x-default": "/vi/clinics",
      },
    },
  };
}

export default async function ClinicsDirectory({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const t = await getTranslations("clinicsSeo");

  let clinicList: Array<{
    id: string;
    name: string;
    address: string;
    phone: string | null;
    specialties: string[];
    verified: boolean;
    rating?: number;
    reviewCount?: number;
    is_24_7?: boolean;
  }> = [];

  if (isSupabaseConfigured()) {
    try {
      const supabase = await createClient();
      const { data } = await supabase
        .from("clinics")
        .select("id,name,address,phone,specialties,verified")
        .eq("published", true)
        .eq("verified", true)
        .eq("is_demo", false)
        .order("name")
        .limit(200);
      if (data && data.length > 0) {
        clinicList = data;
      }
    } catch {}
  }

  // Fallback to rich curated clinics if no database data is found
  if (clinicList.length === 0) {
    const fallback = getFallbackClinics(locale);
    clinicList = fallback.map((c) => ({
      id: c.id,
      name: c.name,
      address: c.address,
      phone: c.phone,
      specialties: c.specialties,
      verified: c.verified,
      rating: c.rating,
      reviewCount: c.reviewCount,
      is_24_7: c.is_24_7,
    }));
  }

  return (
    <main className="mx-auto max-w-6xl space-y-6 px-5 py-8 md:py-12">
      {/* Top Back / Exit Navigation */}
      <div>
        <BackButton
          fallbackHref={`/${locale}`}
          label={locale === "en" ? "Back to Home" : "Quay về Trang chủ"}
          variant="pill"
        />
      </div>

      <header className="flex flex-col gap-4 border-b border-border pb-6 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
              <Stethoscope className="size-3.5 shrink-0" />
              {t("networkBadge")}
            </span>
          </div>
          <h1 className="mt-2 font-display text-3xl font-bold tracking-tight md:text-5xl">
            {t("directoryTitle")}
          </h1>
          <p className="mt-2 max-w-2xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            {t("directoryDescription")} · {t("standardsNotice")}
          </p>
        </div>

        <Link
          href={`/${locale}/clinic-apply`}
          className="inline-flex shrink-0 items-center gap-1.5 self-start rounded-xl border border-border bg-card px-4 py-2.5 text-xs font-bold shadow-2xs transition hover:bg-muted sm:self-auto"
        >
          <span>{t("joinNetwork")}</span>
          <span>→</span>
        </Link>
      </header>

      {/* Directory Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {clinicList.map((clinic) => (
          <Link
            key={clinic.id}
            href={`/${locale}/clinics/${clinic.id}`}
            className="group flex h-full flex-col justify-between rounded-3xl border border-border bg-card p-6 shadow-xs transition hover:border-primary/50 hover:shadow-md"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-1 text-xs font-bold text-primary">
                  <ShieldCheck className="size-4 shrink-0" />
                  <span>{t("verified")}</span>
                </div>
                {clinic.is_24_7 && (
                  <span className="rounded-full bg-destructive/10 px-2.5 py-0.5 text-xs font-bold text-destructive shrink-0">
                    {t("open247")}
                  </span>
                )}
              </div>

              <h2 className="mt-3 font-display text-xl font-bold transition group-hover:text-primary">
                {clinic.name}
              </h2>

              <div className="mt-2 flex items-center gap-1.5 text-xs">
                <div className="flex items-center text-amber-500">
                  <Star className="size-3.5 fill-amber-500" />
                  <span className="ml-1 font-bold text-foreground">
                    {clinic.rating ?? 4.8}
                  </span>
                </div>
                <span className="text-muted-foreground">
                  ({clinic.reviewCount ?? 80}+ {locale === "en" ? "reviews" : "đánh giá"})
                </span>
              </div>

              <p className="mt-3 flex items-start gap-1.5 text-xs text-muted-foreground">
                <MapPin className="size-3.5 shrink-0 mt-0.5" />
                <span className="line-clamp-2">{clinic.address}</span>
              </p>

              <div className="mt-4 flex flex-wrap gap-1.5">
                {clinic.specialties.slice(0, 3).map((spec, idx) => (
                  <span
                    key={idx}
                    className="rounded-lg bg-secondary px-2.5 py-1 text-xs font-medium text-secondary-foreground"
                  >
                    {spec}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-6 flex items-center justify-between border-t border-border pt-4 text-xs font-semibold text-primary">
              <span>{t("viewPricesAndBook")}</span>
              <ArrowRight className="size-4 transition group-hover:translate-x-1" />
            </div>
          </Link>
        ))}
      </div>
    </main>
  );
}
