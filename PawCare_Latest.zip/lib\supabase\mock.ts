export function createDevMockSupabaseClient(userId = "dev-user-id") {
  const samplePets: any[] = [];

  const createQuery = (tableName: string) => {
    const resultData: any = tableName === "pets" ? samplePets : [];
    const query: any = {
      select: () => query,
      insert: () => Promise.resolve({ data: null, error: null }),
      update: () => query,
      upsert: () => Promise.resolve({ data: null, error: null }),
      delete: () => query,
      eq: () => query,
      is: () => query,
      order: () => Promise.resolve({ data: resultData, error: null }),
      limit: () => Promise.resolve({ data: resultData, error: null }),
      single: () => Promise.resolve({ data: resultData[0] || null, error: null }),
      maybeSingle: () => Promise.resolve({ data: resultData[0] || null, error: null }),
      then: (resolve: any) => resolve({ data: resultData, error: null }),
    };
    return query;
  };

  return {
    from: (tableName: string) => createQuery(tableName),
    auth: {
      getUser: async () => ({
        data: {
          user: {
            id: userId,
            email: "demo@pawcare.vn",
            user_metadata: { full_name: "Chủ nuôi thử nghiệm" },
          },
        },
        error: null,
      }),
      signOut: async () => ({ error: null }),
      mfa: {
        getAuthenticatorAssuranceLevel: async () => ({ data: { currentLevel: "aal2" }, error: null }),
      },
    },
  };
}
