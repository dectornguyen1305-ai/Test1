"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { Card } from "@/components/ui/card";
import {
  ShieldCheck,
  Syringe,
  FileText,
  AlertTriangle,
  QrCode,
  Plus,
  CheckCircle2,
  Clock,
  Heart,
  Share2,
  X,
  Maximize2,
} from "lucide-react";
import { AddPetForm } from "./add-pet-form";
import { BackButton } from "@/components/ui/back-button";
import { ImageLightbox } from "@/components/ui/image-lightbox";

export interface PetRecord {
  id: string;
  name: string;
  species: "dog" | "cat" | "other";
  breed?: string;
  birthDate?: string;
  weightKg?: number;
  microchip?: string;
  allergies?: string[];
  conditions?: string[];
  vaccinations: {
    name: string;
    date: string;
    nextDue: string;
    lot: string;
    clinic: string;
    status: "completed" | "due_soon" | "overdue";
  }[];
}

function getLocalizedDefaultPets(_locale: string): PetRecord[] {
  return [];
}

export function PetPassportView({ locale }: { locale: string }) {
  const tOwner = useTranslations("owner");
  const tP = useTranslations("ownerPassport");

  const [pets, setPets] = useState<PetRecord[]>(() => getLocalizedDefaultPets(locale));
  useEffect(() => {
    let list = getLocalizedDefaultPets(locale);
    if (typeof window !== "undefined") {
      try {
        const stored = localStorage.getItem("pawcare-user-pets");
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            const mapped: PetRecord[] = parsed.map((p: any) => ({
              id: p.id || `pet-${Math.random()}`,
              name: p.name,
              species: p.species || "dog",
              breed: p.breed,
              birthDate: p.birthDate,
              weightKg: p.weightKg,
              microchip: p.microchip,
              allergies: p.allergies || [],
              conditions: p.conditions || (p.medicalHistory ? [p.medicalHistory] : []),
              vaccinations: Array.isArray(p.vaccinations) ? p.vaccinations : [],
            }));
            list = [...mapped, ...list];
          }
        }
      } catch {}
    }
    setPets(list);
    if (list.length > 0) setSelectedPetId(list[0].id);
  }, [locale]);
  const [selectedPetId, setSelectedPetId] = useState<string>("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [previewPetPhoto, setPreviewPetPhoto] = useState<PetRecord | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowAddModal(false);
        setShowShareModal(false);
        setPreviewPetPhoto(null);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const currentPet = pets.find((p) => p.id === selectedPetId) ?? pets[0];

  const calculateAge = (birthDateString?: string) => {
    if (!birthDateString) return "";
    const birth = new Date(birthDateString);
    const now = new Date();
    const years = now.getFullYear() - birth.getFullYear();
    const months = now.getMonth() - birth.getMonth();
    const totalMonths = years * 12 + months;
    if (totalMonths < 12) {
      return tP("ageMonths", { count: totalMonths });
    }
    const remMonths = totalMonths % 12;
    if (remMonths > 0) {
      return tP("ageYears", {
        years: Math.floor(totalMonths / 12),
        months: `${remMonths}${locale === "en" ? "m" : "th"}`,
      });
    }
    return tP("ageYearsOnly", { years: Math.floor(totalMonths / 12) });
  };

  return (
    <div className="space-y-6">
      {/* Top Navigation & Exit / Back button */}
      <div className="flex items-center justify-between">
        <BackButton
          fallbackHref={`/${locale}/owner`}
          label={locale === "en" ? "Back to Dashboard" : "Quay lại Tổng quan"}
          variant="pill"
        />
        {previewPetPhoto && (
          <button
            type="button"
            onClick={() => setPreviewPetPhoto(null)}
            className="inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1 text-xs font-semibold text-destructive hover:bg-destructive/20 transition cursor-pointer"
          >
            <X className="size-3.5" />
            <span>{locale === "en" ? "Exit photo preview" : "Thoát xem ảnh"}</span>
          </button>
        )}
      </div>

      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
              <ShieldCheck className="size-3.5 shrink-0" />
              {tP("badge")}
            </span>
          </div>
          <h1 className="mt-2 font-display text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl">
            {tOwner("myPets")} &amp; {tP("title")}
          </h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
            {tP("subtitle")}
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5 shrink-0">
          <button
            onClick={() => setShowAddModal(!showAddModal)}
            className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2.5 text-xs font-semibold text-primary-foreground shadow-sm transition hover:opacity-90 sm:text-sm"
          >
            <Plus className="size-4 shrink-0" />
            <span>{tP("addPet")}</span>
          </button>
          <a
            href="/api/demo/passport.pdf"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-4 py-2.5 text-xs font-semibold transition hover:bg-accent sm:text-sm"
          >
            <FileText className="size-4 shrink-0" />
            <span>{tP("exportPdf")}</span>
          </a>
        </div>
      </div>

      {/* Add Pet Expandable Form */}
      {showAddModal && (
        <Card className="border-primary/40 bg-card p-6 shadow-md transition-all">
          <div className="mb-4 flex items-center justify-between border-b border-border pb-3">
            <h2 className="font-display text-xl font-bold">{tP("addModalTitle")}</h2>
            <button
              onClick={() => setShowAddModal(false)}
              className="inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1 text-xs font-semibold text-destructive hover:bg-destructive/20 transition cursor-pointer"
              aria-label={locale === "en" ? "Exit add pet form" : "Thoát thêm thú cưng"}
            >
              <X className="size-3.5" />
              <span>{locale === "en" ? "Exit form" : "Thoát"}</span>
            </button>
          </div>
          <AddPetForm locale={locale} />
        </Card>
      )}

      {pets.length === 0 ? (
        <Card className="p-8 sm:p-12 text-center space-y-4 max-w-xl mx-auto border-dashed border-border bg-card">
          <div className="grid size-16 place-items-center rounded-3xl bg-primary/10 text-3xl mx-auto shadow-inner">
            🐾
          </div>
          <div>
            <h2 className="font-display text-xl sm:text-2xl font-bold">
              {locale === "en" ? "No pets in passport yet" : "Chưa có thú cưng trong sổ y bạ"}
            </h2>
            <p className="mt-1.5 text-xs sm:text-sm text-muted-foreground max-w-md mx-auto">
              {locale === "en"
                ? "Add your companion to create their cloud medical passport, track vaccinations, and log health records."
                : "Thêm thú cưng của bạn để bắt đầu tạo sổ y bạ đám mây, theo dõi lịch tiêm vắc-xin và cấp phát mã định danh y tế."}
            </p>
          </div>
          <div className="flex flex-wrap items-center justify-center gap-3">
            <Link
              href={`/${locale}/pet-health-setup`}
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground shadow transition hover:opacity-90 cursor-pointer"
            >
              <Heart className="size-4 shrink-0" />
              <span>{locale === "en" ? "Set up Health Profile" : "Thiết lập hồ sơ sức khỏe"}</span>
            </Link>
            <button
              type="button"
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2.5 text-sm font-semibold text-foreground shadow-xs transition hover:bg-muted cursor-pointer"
            >
              <Plus className="size-4 shrink-0" />
              <span>{tP("addPet")}</span>
            </button>
          </div>
        </Card>
      ) : (
        <>
          {/* Pet Selector Tabs */}
          <div className="flex gap-3 overflow-x-auto pb-2">
        {pets.map((pet) => {
          const isSelected = pet.id === currentPet.id;
          return (
            <button
              key={pet.id}
              onClick={() => setSelectedPetId(pet.id)}
              className={`flex shrink-0 items-center gap-3 rounded-2xl border p-3.5 text-left transition ${
                isSelected
                  ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                  : "border-border bg-card hover:border-primary/40 hover:bg-muted/40"
              }`}
            >
              <div className="grid size-12 place-items-center rounded-xl bg-primary/10 text-xl font-bold text-primary">
                {pet.species === "cat" ? "🐱" : pet.species === "dog" ? "🐶" : "🐾"}
              </div>
              <div className="min-w-0">
                <p className="font-bold text-foreground truncate">{pet.name}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {pet.breed ?? (pet.species === "cat" ? tOwner("cat") : tOwner("dog"))}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Pet Detail Grid */}
      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        {/* Main Section: Health Timeline & Vax Passport */}
        <div className="space-y-6">
          {/* Pet Basic Information Card */}
          <Card className="p-6">
            <div className="flex flex-col gap-4 border-b border-border pb-5 sm:flex-row sm:items-center sm:justify-between">
              <div className="flex items-center gap-4 min-w-0">
                <button
                  type="button"
                  onClick={() => setPreviewPetPhoto(currentPet)}
                  className="group relative grid size-16 shrink-0 place-items-center rounded-2xl bg-secondary text-3xl shadow-inner transition hover:ring-2 hover:ring-primary focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring cursor-pointer"
                  title={locale === "en" ? "Click to view photo & details" : "Bấm để xem ảnh & thông tin chi tiết"}
                  aria-label={locale === "en" ? "View enlarged pet photo" : "Xem ảnh phóng to"}
                >
                  <span>{currentPet.species === "cat" ? "🐱" : "🐶"}</span>
                  <span className="absolute -bottom-1 -right-1 grid size-5 place-items-center rounded-full bg-primary text-[10px] text-primary-foreground shadow-xs group-hover:scale-110 transition">
                    <Maximize2 className="size-3" />
                  </span>
                </button>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-display text-2xl font-bold truncate">{currentPet.name}</h2>
                    <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-semibold text-primary">
                      {tP("microchipBadge")}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {currentPet.breed} · {calculateAge(currentPet.birthDate)} ·{" "}
                    <strong>{currentPet.weightKg} kg</strong>
                  </p>
                </div>
              </div>

              <button
                onClick={() => setShowShareModal(true)}
                className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-xl border border-border px-3.5 py-2 text-xs font-semibold transition hover:bg-accent"
              >
                <QrCode className="size-4 text-primary" />
                <span>{tP("shareWithDoctor")}</span>
              </button>
            </div>

            {/* Quick Badges */}
            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <div className="rounded-xl border border-border/80 bg-muted/30 p-3 min-w-0">
                <p className="text-xs text-muted-foreground truncate">{tP("birthDate")}</p>
                <p className="mt-1 font-semibold text-sm truncate">
                  {currentPet.birthDate
                    ? new Intl.DateTimeFormat(locale, { dateStyle: "medium" }).format(
                        new Date(currentPet.birthDate)
                      )
                    : tP("unknown")}
                </p>
              </div>

              <div className="rounded-xl border border-border/80 bg-muted/30 p-3 min-w-0">
                <p className="text-xs text-muted-foreground truncate">{tP("weight")}</p>
                <p className="mt-1 font-semibold text-sm truncate">{currentPet.weightKg} kg</p>
              </div>

              <div className="rounded-xl border border-border/80 bg-muted/30 p-3 min-w-0">
                <p className="text-xs text-muted-foreground truncate">{tP("microchip")}</p>
                <p className="mt-1 font-mono text-xs font-bold text-primary truncate">
                  {currentPet.microchip ?? tP("notChipped")}
                </p>
              </div>

              <div className="rounded-xl border border-border/80 bg-muted/30 p-3 min-w-0">
                <p className="text-xs text-muted-foreground truncate">{tP("vaxStatus")}</p>
                <p className="mt-1 flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 truncate">
                  <CheckCircle2 className="size-3.5 shrink-0" />
                  <span>{tP("vaxUpToDate")}</span>
                </p>
              </div>
            </div>

            {/* Medical Alerts (Allergies / Special Conditions) */}
            {(currentPet.allergies?.length || currentPet.conditions?.length) && (
              <div className="mt-5 rounded-2xl border border-warning/30 bg-warning/5 p-4">
                <div className="flex items-center gap-2 text-warning">
                  <AlertTriangle className="size-4 shrink-0" />
                  <span className="text-xs font-bold uppercase tracking-wider">
                    {tP("medicalAlert")}
                  </span>
                </div>
                <div className="mt-2.5 flex flex-wrap gap-2 text-xs">
                  {currentPet.allergies?.map((allergy) => (
                    <span
                      key={allergy}
                      className="rounded-lg bg-destructive/10 px-2.5 py-1 font-semibold text-destructive"
                    >
                      {tP("allergyLabel")}: {allergy}
                    </span>
                  ))}
                  {currentPet.conditions?.map((cond) => (
                    <span
                      key={cond}
                      className="rounded-lg bg-warning/20 px-2.5 py-1 font-semibold text-amber-800 dark:text-amber-300"
                    >
                      {tP("conditionLabel")}: {cond}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </Card>

          {/* Vaccination Schedule & Records */}
          <Card className="p-6">
            <div className="flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="font-display text-xl font-bold flex items-center gap-2">
                  <Syringe className="size-5 text-primary shrink-0" />
                  {tP("vaxScheduleTitle")}
                </h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {tP("vaxScheduleSubtitle")}
                </p>
              </div>
              <Link
                href={`/${locale}/owner/appointments`}
                className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline shrink-0"
              >
                <span>{tP("bookBooster")}</span>
                <span>→</span>
              </Link>
            </div>

            <div className="mt-5 space-y-3.5">
              {currentPet.vaccinations.map((vax, idx) => {
                const isDueSoon = vax.status === "due_soon";
                return (
                  <div
                    key={idx}
                    className="flex flex-col gap-3 rounded-2xl border border-border p-4 transition hover:border-primary/30 sm:flex-row sm:items-center sm:justify-between"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-bold text-foreground text-sm">{vax.name}</span>
                        {isDueSoon ? (
                          <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                            <Clock className="size-3" /> {tP("dueSoon")}
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                            <CheckCircle2 className="size-3" /> {tP("completed")}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {tP("lot")}: <code className="font-mono">{vax.lot}</code> · {vax.clinic}
                      </p>
                    </div>

                    <div className="text-left sm:text-right text-xs shrink-0">
                      <p className="text-muted-foreground">{tP("vaxDate")}: {vax.date}</p>
                      <p className="font-semibold text-primary">{tP("nextDue")}: {vax.nextDue}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Sidebar: Quick Actions & Sharing QR */}
        <div className="space-y-6">
          {/* Digital Pet Card / Medical Passport Badge */}
          <Card className="relative overflow-hidden bg-gradient-to-br from-primary/15 via-card to-secondary/30 p-6 border-primary/30">
            <div className="flex items-center justify-between">
              <span className="font-display font-bold text-primary">PawCare ID</span>
              <span className="text-xs font-semibold uppercase text-muted-foreground">
                Vietnam Pet Care
              </span>
            </div>

            <div className="mt-6 flex items-center gap-3">
              <div className="grid size-14 shrink-0 place-items-center rounded-2xl bg-primary text-2xl text-primary-foreground shadow-md">
                🐾
              </div>
              <div className="min-w-0">
                <h4 className="font-display text-xl font-bold truncate">{currentPet.name}</h4>
                <p className="text-xs text-muted-foreground truncate">{currentPet.breed}</p>
                <p className="font-mono text-xs text-primary">{currentPet.id}</p>
              </div>
            </div>

            <div className="mt-6 rounded-xl bg-card/80 p-3 text-xs backdrop-blur-xs space-y-1">
              <div className="flex justify-between gap-2">
                <span className="text-muted-foreground shrink-0">{tP("ownerLabel")}:</span>
                <span className="font-semibold truncate">{tP("verifiedAccount")}</span>
              </div>
              <div className="flex justify-between gap-2">
                <span className="text-muted-foreground shrink-0">{tP("passportStatus")}:</span>
                <span className="font-semibold text-emerald-600 truncate">{tP("validStatus")}</span>
              </div>
            </div>

            <button
              onClick={() => setShowShareModal(true)}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-xs font-semibold text-primary-foreground shadow transition hover:opacity-95"
            >
              <Share2 className="size-3.5 shrink-0" />
              <span>{tP("generateQr")}</span>
            </button>
          </Card>

          {/* Quick Care Guidelines */}
          <Card className="p-5">
            <h4 className="font-bold text-sm flex items-center gap-2 text-foreground">
              <Heart className="size-4 text-destructive shrink-0" />
              {tP("routineCare")}
            </h4>
            <ul className="mt-3 space-y-2.5 text-xs text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">✓</span>
                <span>{tP("careItem1")}</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">✓</span>
                <span>{tP("careItem2")}</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary font-bold">✓</span>
                <span>{tP("careItem3")}</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
        </>
      )}

      {/* Share Modal Dialog */}
      {showShareModal && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowShareModal(false);
          }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in"
        >
          <div className="w-full max-w-sm rounded-3xl border border-border bg-card p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="font-display font-bold">{tP("qrModalTitle")}</h3>
              <button
                onClick={() => setShowShareModal(false)}
                className="inline-flex items-center gap-1 rounded-full bg-secondary px-2.5 py-1 text-xs font-semibold text-secondary-foreground hover:bg-muted transition cursor-pointer"
                aria-label={locale === "en" ? "Exit QR share" : "Thoát chia sẻ QR"}
              >
                <X className="size-3.5" />
                <span>{locale === "en" ? "Exit" : "Thoát"}</span>
              </button>
            </div>

            <div className="my-6 text-center">
              <div className="mx-auto grid size-48 place-items-center rounded-2xl border-2 border-dashed border-primary bg-secondary/30 p-4">
                <QrCode className="size-36 text-primary" />
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                {tP("qrModalDesc")}
              </p>
            </div>

            <button
              onClick={() => setShowShareModal(false)}
              className="w-full rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground hover:opacity-90 transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <X className="size-4" />
              <span>{locale === "en" ? "Exit / Close QR" : "Thoát / Đóng mã QR"}</span>
            </button>
          </div>
        </div>
      )}

      {/* Pet Photo / Full Profile Lightbox */}
      <ImageLightbox
        isOpen={Boolean(previewPetPhoto)}
        onClose={() => setPreviewPetPhoto(null)}
        title={`${previewPetPhoto?.name} — ${previewPetPhoto?.breed ?? (previewPetPhoto?.species === "cat" ? tOwner("cat") : tOwner("dog"))}`}
        subtitle={previewPetPhoto?.microchip ? `Microchip: ${previewPetPhoto.microchip}` : undefined}
        locale={locale}
      >
        {previewPetPhoto && (
          <div className="flex flex-col items-center text-center p-4 max-w-md w-full">
            <div className="grid size-32 place-items-center rounded-3xl bg-secondary text-6xl shadow-md border border-border">
              {previewPetPhoto.species === "cat" ? "🐱" : "🐶"}
            </div>
            <h4 className="mt-4 font-display text-2xl font-bold text-foreground">
              {previewPetPhoto.name}
            </h4>
            <p className="text-sm text-muted-foreground mt-1">
              {previewPetPhoto.breed} · {calculateAge(previewPetPhoto.birthDate)} · <strong>{previewPetPhoto.weightKg} kg</strong>
            </p>

            <div className="mt-4 w-full rounded-2xl border border-border bg-card p-3.5 text-xs text-left space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">{tP("microchip")}:</span>
                <span className="font-mono font-bold text-primary">{previewPetPhoto.microchip ?? tP("notChipped")}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">{tP("vaxStatus")}:</span>
                <span className="font-semibold text-emerald-600">{tP("vaxUpToDate")} ({previewPetPhoto.vaccinations.length} liều)</span>
              </div>
              {Boolean(previewPetPhoto.allergies?.length) && (
                <div className="flex justify-between text-destructive">
                  <span>{tP("allergyLabel")}:</span>
                  <span className="font-semibold">{previewPetPhoto.allergies?.join(", ")}</span>
                </div>
              )}
            </div>
          </div>
        )}
      </ImageLightbox>
    </div>
  );
}
