import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { LocaleSwitcher } from "./locale-switcher";
import { ThemeToggle } from "./theme-toggle";
import { AccountNav } from "./account-nav";
import { getOptionalUser } from "@/lib/auth/server";

export async function PublicHeader({ locale }: { locale: string }) {
  const t = await getTranslations("common");
  const d = await getTranslations("demo");
  const c = await getTranslations("clinicsSeo");
  const user = await getOptionalUser();

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/40 bg-background/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 sm:px-6 md:px-8">
        <Link href={`/${locale}`} className="shrink-0 font-display text-2xl font-bold tracking-tight text-primary">
          {t("brand")}
        </Link>
        <nav className="flex items-center gap-1.5 sm:gap-2.5 md:gap-3">
          <Link
            href={`/${locale}/clinics`}
            className="hidden shrink-0 rounded-full px-3 py-1.5 text-xs font-semibold transition hover:bg-secondary sm:text-sm lg:inline-flex"
          >
            {c("directoryTitle")}
          </Link>
          <Link
            href={`/${locale}/demo`}
            className="hidden shrink-0 rounded-full border border-border px-3 py-1.5 text-xs font-semibold transition hover:bg-muted sm:text-sm md:inline-flex"
          >
            {d("title")}
          </Link>
          <div className="shrink-0">
            <ThemeToggle />
          </div>
          <div className="shrink-0">
            <LocaleSwitcher />
          </div>
          <div className="shrink-0">
            <AccountNav user={user} />
          </div>
        </nav>
      </div>
    </header>
  );
}
