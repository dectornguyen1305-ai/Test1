"use client";

import { useEffect, useState } from "react";
import { Sun, Moon, Laptop } from "lucide-react";

export type ThemeMode = "light" | "dark" | "system";

export function ThemeToggle({
  variant = "icon",
  className = "",
}: {
  variant?: "icon" | "select" | "buttons";
  className?: string;
}) {
  const [theme, setTheme] = useState<ThemeMode>("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const saved = localStorage.getItem("pawcare-theme") as ThemeMode | null;
    if (saved === "light" || saved === "dark" || saved === "system") {
      setTheme(saved);
      applyTheme(saved);
    } else {
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      setTheme(prefersDark ? "dark" : "light");
    }
  }, []);

  const applyTheme = (mode: ThemeMode) => {
    const isDark =
      mode === "dark" ||
      (mode === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);

    if (isDark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  const changeTheme = (newMode: ThemeMode) => {
    setTheme(newMode);
    localStorage.setItem("pawcare-theme", newMode);
    applyTheme(newMode);
  };

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    changeTheme(next);
  };

  if (!mounted) {
    return (
      <button
        type="button"
        aria-label="Toggle theme"
        className={`grid size-9 place-items-center rounded-full border border-border bg-card text-muted-foreground shadow-2xs ${className}`}
      >
        <Sun className="size-4" />
      </button>
    );
  }

  if (variant === "buttons") {
    return (
      <div className={`grid grid-cols-3 gap-2 rounded-2xl border border-border bg-muted/40 p-1.5 ${className}`}>
        <button
          type="button"
          onClick={() => changeTheme("light")}
          className={`flex items-center justify-center gap-2 rounded-xl py-2 px-3 text-xs font-bold transition cursor-pointer ${
            theme === "light"
              ? "bg-card text-foreground shadow-xs ring-1 ring-border"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Sun className="size-3.5 text-amber-500 shrink-0" />
          <span>Sáng (Light)</span>
        </button>

        <button
          type="button"
          onClick={() => changeTheme("dark")}
          className={`flex items-center justify-center gap-2 rounded-xl py-2 px-3 text-xs font-bold transition cursor-pointer ${
            theme === "dark"
              ? "bg-card text-foreground shadow-xs ring-1 ring-border"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Moon className="size-3.5 text-blue-400 shrink-0" />
          <span>Tối (Dark)</span>
        </button>

        <button
          type="button"
          onClick={() => changeTheme("system")}
          className={`flex items-center justify-center gap-2 rounded-xl py-2 px-3 text-xs font-bold transition cursor-pointer ${
            theme === "system"
              ? "bg-card text-foreground shadow-xs ring-1 ring-border"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          <Laptop className="size-3.5 text-muted-foreground shrink-0" />
          <span>Hệ thống</span>
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      onClick={toggleTheme}
      title={theme === "dark" ? "Chuyển sang giao diện Sáng" : "Chuyển sang giao diện Tối (Dark Theme)"}
      aria-label={theme === "dark" ? "Switch to Light Theme" : "Switch to Dark Theme"}
      className={`grid size-9 place-items-center rounded-full border border-border bg-card text-foreground hover:bg-muted shadow-2xs transition-all cursor-pointer ${className}`}
    >
      {theme === "dark" ? (
        <Sun className="size-4 text-amber-400 transition-transform rotate-0 hover:rotate-45" />
      ) : (
        <Moon className="size-4 text-slate-700 dark:text-slate-200 transition-transform -rotate-12 hover:rotate-0" />
      )}
    </button>
  );
}
