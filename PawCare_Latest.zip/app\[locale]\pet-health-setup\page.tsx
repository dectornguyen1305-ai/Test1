import type { Metadata } from "next";
import Link from "next/link";
import { getTranslations } from "next-intl/server";
import { HealthProfileSetupForm } from "@/components/pet/health-profile-setup-form";
import { LocaleSwitcher } from "@/components/shell/locale-switcher";
import { ThemeToggle } from "@/components/shell/theme-toggle";
import { BackButton } from "@/components/ui/back-button";
import { ShieldCheck, HeartPulse } from "lucide-react";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "petHealthSetup" });
  return {
    title: `${t("title")} — PawCare`,
    description: t("subtitle"),
  };
}

export default async function PetHealthSetupPage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  const t = await getTranslations("petHealthSetup");
  const common = await getTranslations("common");
  const isEn = locale === "en";

  return (
    <div className="min-h-screen bg-background">
      {/* Top Header Bar */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <BackButton
              fallbackHref={`/${locale}`}
              label={isEn ? "Back to Home" : "Quay về Trang chủ"}
              variant="pill"
            />
            <Link
              href={`/${locale}`}
              className="font-display text-xl font-bold text-primary transition hover:opacity-90"
            >
              {common("brand")}
            </Link>
          </div>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            <LocaleSwitcher />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="mx-auto max-w-4xl px-4 py-10 sm:px-6 sm:py-14">
        {/* Page Hero Title */}
        <div className="mb-10 text-center">
          <p className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-secondary px-3.5 py-1.5 text-xs font-semibold text-secondary-foreground">
            <HeartPulse className="size-3.5 text-primary" />
            <span>{t("badge")}</span>
          </p>
          <h1 className="font-display text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
            {t("title")}
          </h1>
          <p className="mx-auto mt-3 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
            {t("subtitle")}
          </p>
        </div>

        {/* Interactive Form */}
        <HealthProfileSetupForm locale={locale} />

        {/* Security / Privacy Footnote */}
        <div className="mt-12 text-center text-xs text-muted-foreground">
          <p className="inline-flex items-center gap-1.5">
            <ShieldCheck className="size-4 text-emerald-500" />
            <span>
              {isEn
                ? "Your pet's health records are encrypted and protected under PawCare Data Standards."
                : "Hồ sơ y bạ của thú cưng được mã hóa và bảo mật theo Tiêu chuẩn Dữ liệu PawCare."}
            </span>
          </p>
        </div>
      </main>
    </div>
  );
}
