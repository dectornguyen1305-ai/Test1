"use client";

import { useState } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import {
  PawPrint,
  CheckCircle2,
  AlertCircle,
  Syringe,
  FileText,
  Calendar,
  Sparkles,
  ArrowRight,
  Plus,
  Trash2,
  ShieldCheck,
  HeartPulse,
  RotateCcw,
  Check,
} from "lucide-react";

export interface PetHealthProfile {
  id: string;
  name: string;
  species: "dog" | "cat" | "other";
  breed: string;
  gender: "male" | "female" | "neutered";
  age: string;
  birthDate?: string;
  weightKg: number;
  microchip: string;
  medicalHistory: string;
  allergies: string[];
  conditions: string[];
  isVaccinated: boolean;
  vaccinations: {
    name: string;
    date: string;
    nextDue: string;
    lot: string;
    clinic: string;
    status: "completed" | "due_soon" | "overdue";
  }[];
  notes?: string;
  createdAt: string;
}

interface CustomVax {
  id: string;
  name: string;
  date: string;
}

export function HealthProfileSetupForm({ locale }: { locale: string }) {
  const t = useTranslations("petHealthSetup");
  const isEn = locale === "en";

  // Form Fields State
  const [name, setName] = useState("");
  const [species, setSpecies] = useState<"dog" | "cat" | "other">("dog");
  const [breed, setBreed] = useState("");
  const [gender, setGender] = useState<"male" | "female" | "neutered">("male");
  const [ageYears, setAgeYears] = useState("1");
  const [ageMonths, setAgeMonths] = useState("0");
  const [birthDate, setBirthDate] = useState("");
  const [weight, setWeight] = useState("");
  const [medicalHistory, setMedicalHistory] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [isVaccinated, setIsVaccinated] = useState<boolean>(true);
  const [selectedVaxes, setSelectedVaxes] = useState<string[]>([
    isEn ? "Rabies vaccine" : "Vắc-xin Dại (Rabies)",
    isEn
      ? "Core multi-disease vaccine"
      : "Vắc-xin phòng bệnh truyền nhiễm",
  ]);
  const [customVaxes, setCustomVaxes] = useState<CustomVax[]>([]);
  const [newVaxName, setNewVaxName] = useState("");
  const [lastVaxDate, setLastVaxDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [notes, setNotes] = useState("");

  // Validation & Submission State
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [savedPet, setSavedPet] = useState<PetHealthProfile | null>(null);

  // Quick select medical condition tags
  const quickTags = [
    { id: "healthy", label: t("healthyTag") },
    { id: "food_allergy", label: t("foodAllergyTag") },
    { id: "drug_allergy", label: t("drugAllergyTag") },
    { id: "surgery", label: t("surgeryTag") },
    { id: "chronic", label: t("chronicTag") },
  ];

  const handleToggleTag = (tagLabel: string) => {
    setSelectedTags((prev) => {
      if (prev.includes(tagLabel)) {
        return prev.filter((item) => item !== tagLabel);
      } else {
        return [...prev, tagLabel];
      }
    });
  };

  const handleToggleVax = (vaxName: string) => {
    setSelectedVaxes((prev) =>
      prev.includes(vaxName)
        ? prev.filter((v) => v !== vaxName)
        : [...prev, vaxName]
    );
  };

  const handleAddCustomVax = () => {
    if (!newVaxName.trim()) return;
    setCustomVaxes((prev) => [
      ...prev,
      {
        id: `vax-${Date.now()}`,
        name: newVaxName.trim(),
        date: lastVaxDate || new Date().toISOString().split("T")[0],
      },
    ]);
    setNewVaxName("");
  };

  const handleRemoveCustomVax = (id: string) => {
    setCustomVaxes((prev) => prev.filter((v) => v.id !== id));
  };

  const formatAgeString = () => {
    const y = parseInt(ageYears, 10) || 0;
    const m = parseInt(ageMonths, 10) || 0;
    if (y === 0 && m === 0) {
      return isEn ? "Under 1 year" : "Dưới 1 tuổi";
    }
    if (y > 0 && m > 0) {
      return isEn
        ? `${y} year${y > 1 ? "s" : ""} ${m} month${m > 1 ? "s" : ""}`
        : `${y} tuổi ${m} tháng`;
    }
    if (y > 0) {
      return isEn ? `${y} year${y > 1 ? "s" : ""} old` : `${y} tuổi`;
    }
    return isEn ? `${m} month${m > 1 ? "s" : ""} old` : `${m} tháng tuổi`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!name.trim()) {
      setErrorMsg(t("errorNameRequired"));
      return;
    }

    setIsSubmitting(true);

    try {
      // Build final medical history summary
      let finalMedicalHistory = medicalHistory.trim();
      if (selectedTags.length > 0) {
        const tagText = selectedTags.join(", ");
        finalMedicalHistory = finalMedicalHistory
          ? `${tagText}. ${finalMedicalHistory}`
          : tagText;
      }
      if (!finalMedicalHistory) {
        finalMedicalHistory = isEn
          ? "Healthy, no chronic conditions recorded."
          : "Khỏe mạnh, chưa ghi nhận bệnh nền.";
      }

      // Build vaccine items
      const allVaccines = isVaccinated
        ? [
            ...selectedVaxes.map((v) => ({
              name: v,
              date: lastVaxDate || new Date().toISOString().split("T")[0],
              nextDue: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
                .toISOString()
                .split("T")[0],
              lot: `LOT-${Math.floor(1000 + Math.random() * 9000)}`,
              clinic: isEn
                ? "PawCare Partner Veterinary Clinic"
                : "Phòng khám thú y đối tác PawCare",
              status: "completed" as const,
            })),
            ...customVaxes.map((cv) => ({
              name: cv.name,
              date: cv.date || new Date().toISOString().split("T")[0],
              nextDue: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
                .toISOString()
                .split("T")[0],
              lot: `LOT-${Math.floor(1000 + Math.random() * 9000)}`,
              clinic: isEn
                ? "PawCare Partner Veterinary Clinic"
                : "Phòng khám thú y đối tác PawCare",
              status: "completed" as const,
            })),
          ]
        : [];

      const newPet: PetHealthProfile = {
        id: `pet-${Date.now()}`,
        name: name.trim(),
        species,
        breed:
          breed.trim() ||
          (species === "cat"
            ? isEn
              ? "Cat"
              : "Mèo nhà"
            : species === "dog"
            ? isEn
              ? "Dog"
              : "Chó nhà"
            : isEn
            ? "Companion Pet"
            : "Thú cưng"),
        gender,
        age: formatAgeString(),
        birthDate: birthDate || undefined,
        weightKg: parseFloat(weight) || (species === "cat" ? 4.0 : 8.5),
        microchip: `VN-PC-${Math.floor(100000 + Math.random() * 900000)}`,
        medicalHistory: finalMedicalHistory,
        allergies: selectedTags.filter((t) =>
          t.toLowerCase().includes("allergy") || t.toLowerCase().includes("dị ứng")
        ),
        conditions: selectedTags.filter(
          (t) =>
            !t.toLowerCase().includes("allergy") &&
            !t.toLowerCase().includes("dị ứng")
        ),
        isVaccinated,
        vaccinations: allVaccines,
        notes: notes.trim(),
        createdAt: new Date().toISOString(),
      };

      // Save to localStorage
      if (typeof window !== "undefined") {
        try {
          const rawExisting = localStorage.getItem("pawcare-user-pets");
          const existingList: PetHealthProfile[] = rawExisting
            ? JSON.parse(rawExisting)
            : [];
          const updatedList = [newPet, ...existingList];
          localStorage.setItem("pawcare-user-pets", JSON.stringify(updatedList));

          // Dispatch event to inform other active components (e.g., Settings, Passport)
          window.dispatchEvent(
            new CustomEvent("pawcare-pets-updated", { detail: updatedList })
          );
        } catch {
          // localStorage fallback
        }
      }

      setSavedPet(newPet);
    } catch (err: any) {
      setErrorMsg(err?.message || "Đã xảy ra lỗi khi lưu thông tin.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleResetForm = () => {
    setName("");
    setSpecies("dog");
    setBreed("");
    setGender("male");
    setAgeYears("1");
    setAgeMonths("0");
    setBirthDate("");
    setWeight("");
    setMedicalHistory("");
    setSelectedTags([]);
    setIsVaccinated(true);
    setSelectedVaxes([
      isEn ? "Rabies vaccine" : "Vắc-xin Dại (Rabies)",
      isEn
        ? "Core multi-disease vaccine"
        : "Vắc-xin phòng bệnh truyền nhiễm",
    ]);
    setCustomVaxes([]);
    setNotes("");
    setSavedPet(null);
    setErrorMsg(null);
  };

  // SUCCESS SCREEN
  if (savedPet) {
    return (
      <div className="mx-auto max-w-2xl">
        <div className="rounded-3xl border border-border bg-card p-6 shadow-sm md:p-10 text-center space-y-6">
          <div className="mx-auto grid size-16 place-items-center rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400">
            <CheckCircle2 className="size-10" />
          </div>

          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
              <ShieldCheck className="size-3.5" />
              <span>{isEn ? "Verified & Active" : "Đã xác thực & Kích hoạt"}</span>
            </span>
            <h2 className="mt-3 font-display text-2xl font-bold md:text-3xl">
              {t("successTitle")}
            </h2>
            <p className="mt-2 text-sm text-muted-foreground max-w-md mx-auto">
              {t("successSubtitle")}
            </p>
          </div>

          {/* Pet Passport Card Preview */}
          <div className="rounded-2xl border border-border bg-muted/20 p-5 md:p-6 text-left space-y-4">
            <div className="flex items-center justify-between border-b border-border pb-4">
              <div className="flex items-center gap-3.5">
                <div className="grid size-14 place-items-center rounded-2xl bg-secondary text-3xl shadow-inner">
                  {savedPet.species === "cat"
                    ? "🐱"
                    : savedPet.species === "dog"
                    ? "🐶"
                    : "🐾"}
                </div>
                <div>
                  <h3 className="font-display text-xl font-bold text-foreground">
                    {savedPet.name}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {savedPet.breed} •{" "}
                    {savedPet.gender === "male"
                      ? t("male")
                      : savedPet.gender === "female"
                      ? t("female")
                      : t("neutered")}
                  </p>
                </div>
              </div>

              <div className="text-right">
                <span className="block text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                  {t("passportCode")}
                </span>
                <span className="font-mono text-xs font-bold text-primary">
                  {savedPet.microchip}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs sm:grid-cols-4">
              <div className="rounded-xl border border-border/60 bg-card p-3">
                <span className="block text-muted-foreground">{t("age")}</span>
                <strong className="block text-foreground mt-0.5">{savedPet.age}</strong>
              </div>
              <div className="rounded-xl border border-border/60 bg-card p-3">
                <span className="block text-muted-foreground">{t("gender")}</span>
                <strong className="block text-foreground mt-0.5">
                  {savedPet.gender === "male"
                    ? t("male")
                    : savedPet.gender === "female"
                    ? t("female")
                    : t("neutered")}
                </strong>
              </div>
              <div className="rounded-xl border border-border/60 bg-card p-3">
                <span className="block text-muted-foreground">{t("weight")}</span>
                <strong className="block text-foreground mt-0.5">
                  {savedPet.weightKg} kg
                </strong>
              </div>
              <div className="rounded-xl border border-border/60 bg-card p-3">
                <span className="block text-muted-foreground">
                  {t("sectionVaccine")}
                </span>
                <strong className="block text-emerald-600 dark:text-emerald-400 mt-0.5">
                  {savedPet.isVaccinated
                    ? isEn
                      ? `${savedPet.vaccinations.length} vaccines`
                      : `${savedPet.vaccinations.length} mũi tiêm`
                    : isEn
                    ? "Pending"
                    : "Chưa tiêm"}
                </strong>
              </div>
            </div>

            {/* Medical History */}
            <div className="rounded-xl border border-border/60 bg-card p-3.5 text-xs space-y-1">
              <span className="font-semibold text-foreground block flex items-center gap-1.5">
                <FileText className="size-3.5 text-primary" />
                <span>{t("medicalHistory")}:</span>
              </span>
              <p className="text-muted-foreground leading-relaxed">
                {savedPet.medicalHistory}
              </p>
            </div>

            {/* Vaccination list preview */}
            {savedPet.isVaccinated && savedPet.vaccinations.length > 0 && (
              <div className="rounded-xl border border-border/60 bg-card p-3.5 text-xs space-y-2">
                <span className="font-semibold text-foreground block flex items-center gap-1.5">
                  <Syringe className="size-3.5 text-primary" />
                  <span>{t("vaxListTitle")}</span>
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {savedPet.vaccinations.map((vx, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-0.5 font-medium text-primary text-[11px]"
                    >
                      <Check className="size-3" />
                      {vx.name}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Action CTAs */}
          <div className="grid gap-3 sm:grid-cols-2 pt-2">
            <Link
              href={`/${locale}/owner/pets`}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow transition hover:opacity-95"
            >
              <span>{t("btnViewPassport")}</span>
              <ArrowRight className="size-4" />
            </Link>

            <Link
              href={`/${locale}/settings#pets`}
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-border bg-card px-5 py-3 text-sm font-semibold text-foreground shadow-xs transition hover:bg-muted"
            >
              <span>{t("btnViewSettings")}</span>
            </Link>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-2 text-xs text-muted-foreground">
            <button
              type="button"
              onClick={handleResetForm}
              className="inline-flex items-center gap-1.5 font-medium text-primary hover:underline"
            >
              <RotateCcw className="size-3.5" />
              <span>{t("btnCreateAnother")}</span>
            </button>
            <span>•</span>
            <Link
              href={`/${locale}`}
              className="font-medium text-muted-foreground hover:text-foreground hover:underline"
            >
              {t("btnBackHome")}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // MAIN FORM SCREEN
  return (
    <form onSubmit={handleSubmit} className="mx-auto max-w-2xl space-y-8">
      {/* SECTION 1: Basic Pet Info */}
      <div className="rounded-3xl border border-border bg-card p-6 shadow-sm md:p-8 space-y-6">
        <div className="border-b border-border pb-4">
          <div className="flex items-center gap-2.5 text-primary">
            <PawPrint className="size-5" />
            <span className="text-xs font-bold uppercase tracking-wider">
              {t("sectionBasic")}
            </span>
          </div>
          <h2 className="mt-1 font-display text-xl font-bold">
            {t("sectionBasic")}
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            {t("sectionBasicDesc")}
          </p>
        </div>

        {errorMsg && (
          <div
            role="alert"
            className="flex items-center gap-2.5 rounded-2xl border border-destructive/30 bg-destructive/10 p-3.5 text-xs font-medium text-destructive"
          >
            <AlertCircle className="size-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Pet Name */}
        <div className="space-y-1.5">
          <label
            htmlFor="pet-name"
            className="text-xs font-bold uppercase tracking-wider text-muted-foreground"
          >
            {t("petName")} <span className="text-destructive">*</span>
          </label>
          <input
            id="pet-name"
            type="text"
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={t("petNamePlaceholder")}
            className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm font-medium transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>

        {/* Species Selector */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            {t("species")} <span className="text-destructive">*</span>
          </label>
          <div className="grid grid-cols-3 gap-2.5">
            {[
              { id: "dog", label: t("dog"), icon: "🐶" },
              { id: "cat", label: t("cat"), icon: "🐱" },
              { id: "other", label: t("other"), icon: "🐾" },
            ].map((sp) => (
              <button
                key={sp.id}
                type="button"
                onClick={() => setSpecies(sp.id as any)}
                className={`flex flex-col items-center justify-center gap-1.5 rounded-2xl border p-3.5 text-xs font-bold transition ${
                  species === sp.id
                    ? "border-primary bg-primary/10 text-primary shadow-xs"
                    : "border-border bg-background text-muted-foreground hover:border-border hover:bg-muted/40"
                }`}
              >
                <span className="text-2xl">{sp.icon}</span>
                <span>{sp.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Breed */}
        <div className="space-y-1.5">
          <label
            htmlFor="pet-breed"
            className="text-xs font-bold uppercase tracking-wider text-muted-foreground"
          >
            {t("breed")}
          </label>
          <input
            id="pet-breed"
            type="text"
            value={breed}
            onChange={(e) => setBreed(e.target.value)}
            placeholder={t("breedPlaceholder")}
            className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>

        {/* Gender */}
        <div className="space-y-1.5">
          <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            {t("gender")} <span className="text-destructive">*</span>
          </label>
          <div className="grid grid-cols-3 gap-2.5">
            {[
              { id: "male", label: t("male") },
              { id: "female", label: t("female") },
              { id: "neutered", label: t("neutered") },
            ].map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => setGender(g.id as any)}
                className={`rounded-2xl border py-2.5 px-3 text-xs font-bold text-center transition ${
                  gender === g.id
                    ? "border-primary bg-primary text-primary-foreground shadow-xs"
                    : "border-border bg-background text-foreground hover:bg-muted"
                }`}
              >
                {g.label}
              </button>
            ))}
          </div>
        </div>

        {/* Age and Weight */}
        <div className="grid gap-4 sm:grid-cols-2">
          {/* Age (Years + Months) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              {t("age")} <span className="text-destructive">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center rounded-2xl border border-border bg-background px-3 py-2">
                <input
                  type="number"
                  min="0"
                  max="35"
                  value={ageYears}
                  onChange={(e) => setAgeYears(e.target.value)}
                  className="w-full bg-transparent text-sm font-bold focus:outline-none"
                />
                <span className="text-xs font-medium text-muted-foreground ml-1">
                  {t("ageYears")}
                </span>
              </div>
              <div className="flex items-center rounded-2xl border border-border bg-background px-3 py-2">
                <input
                  type="number"
                  min="0"
                  max="11"
                  value={ageMonths}
                  onChange={(e) => setAgeMonths(e.target.value)}
                  className="w-full bg-transparent text-sm font-bold focus:outline-none"
                />
                <span className="text-xs font-medium text-muted-foreground ml-1">
                  {t("ageMonths")}
                </span>
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              {formatAgeString()}
            </p>
          </div>

          {/* Weight */}
          <div className="space-y-1.5">
            <label
              htmlFor="pet-weight"
              className="text-xs font-bold uppercase tracking-wider text-muted-foreground"
            >
              {t("weight")}
            </label>
            <div className="relative">
              <input
                id="pet-weight"
                type="number"
                step="0.1"
                min="0.1"
                max="120"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                placeholder={t("weightPlaceholder")}
                className="w-full rounded-2xl border border-border bg-background px-4 py-3 pr-10 text-sm transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-muted-foreground">
                kg
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 2: Medical History & Allergies */}
      <div className="rounded-3xl border border-border bg-card p-6 shadow-sm md:p-8 space-y-6">
        <div className="border-b border-border pb-4">
          <div className="flex items-center gap-2.5 text-accent">
            <HeartPulse className="size-5" />
            <span className="text-xs font-bold uppercase tracking-wider">
              {t("sectionMedical")}
            </span>
          </div>
          <h2 className="mt-1 font-display text-xl font-bold">
            {t("sectionMedical")}
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            {t("sectionMedicalDesc")}
          </p>
        </div>

        {/* Quick select tags */}
        <div className="space-y-2">
          <span className="text-xs font-semibold text-muted-foreground block">
            {t("quickTags")}
          </span>
          <div className="flex flex-wrap gap-2">
            {quickTags.map((tag) => {
              const isSelected = selectedTags.includes(tag.label);
              return (
                <button
                  key={tag.id}
                  type="button"
                  onClick={() => handleToggleTag(tag.label)}
                  className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-xs font-medium transition ${
                    isSelected
                      ? "bg-primary text-primary-foreground shadow-xs"
                      : "border border-border bg-muted/40 text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                >
                  {isSelected && <Check className="size-3" />}
                  <span>{tag.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Detailed Medical History */}
        <div className="space-y-1.5">
          <label
            htmlFor="medical-history"
            className="text-xs font-bold uppercase tracking-wider text-muted-foreground"
          >
            {t("medicalHistory")}
          </label>
          <textarea
            id="medical-history"
            rows={3}
            value={medicalHistory}
            onChange={(e) => setMedicalHistory(e.target.value)}
            placeholder={t("medicalHistoryPlaceholder")}
            className="w-full rounded-2xl border border-border bg-background p-4 text-sm leading-relaxed transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>
      </div>

      {/* SECTION 3: Vaccination Status */}
      <div className="rounded-3xl border border-border bg-card p-6 shadow-sm md:p-8 space-y-6">
        <div className="border-b border-border pb-4">
          <div className="flex items-center gap-2.5 text-primary">
            <Syringe className="size-5" />
            <span className="text-xs font-bold uppercase tracking-wider">
              {t("sectionVaccine")}
            </span>
          </div>
          <h2 className="mt-1 font-display text-xl font-bold">
            {t("sectionVaccine")}
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            {t("sectionVaccineDesc")}
          </p>
        </div>

        {/* Vaccinated Yes / No Toggle */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
            {t("vaxStatusQuestion")} <span className="text-destructive">*</span>
          </label>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setIsVaccinated(true)}
              className={`flex items-center justify-center gap-2 rounded-2xl border p-4 text-xs font-bold transition ${
                isVaccinated
                  ? "border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 shadow-xs"
                  : "border-border bg-background text-muted-foreground hover:bg-muted"
              }`}
            >
              <CheckCircle2 className="size-4" />
              <span>{t("vaxYes")}</span>
            </button>
            <button
              type="button"
              onClick={() => setIsVaccinated(false)}
              className={`flex items-center justify-center gap-2 rounded-2xl border p-4 text-xs font-bold transition ${
                !isVaccinated
                  ? "border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400 shadow-xs"
                  : "border-border bg-background text-muted-foreground hover:bg-muted"
              }`}
            >
              <AlertCircle className="size-4" />
              <span>{t("vaxNo")}</span>
            </button>
          </div>
        </div>

        {/* When Vaccinated: List of Core Vaccines */}
        {isVaccinated ? (
          <div className="space-y-4 rounded-2xl border border-border/80 bg-muted/15 p-4 sm:p-5">
            <span className="text-xs font-bold uppercase tracking-wider text-foreground block">
              {t("vaxListTitle")}
            </span>

            <div className="space-y-2.5">
              {[
                {
                  name: t("vaxRabies"),
                  note: isEn ? "Mandatory annual rabies protection" : "Phòng bệnh Dại bắt buộc hàng năm",
                },
                species === "cat"
                  ? {
                      name: t("vaxCoreCat"),
                      note: isEn ? "Core 4-way feline protection" : "Phòng 4 bệnh cốt lõi ở mèo",
                    }
                  : {
                      name: t("vaxCoreDog"),
                      note: isEn ? "Core multi-agent puppy protection" : "Phòng 5 bệnh / 7 bệnh cốt lõi ở chó",
                    },
                {
                  name: t("vaxDeworm"),
                  note: isEn ? "Quarterly parasite protocol" : "Quy trình sổ giun & phòng rận định kỳ",
                },
              ].map((vaxItem, idx) => {
                const checked = selectedVaxes.includes(vaxItem.name);
                return (
                  <label
                    key={idx}
                    className={`flex items-start gap-3 rounded-xl border p-3 cursor-pointer transition ${
                      checked
                        ? "border-primary/50 bg-primary/5 text-foreground"
                        : "border-border/60 bg-card text-muted-foreground hover:bg-muted/30"
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => handleToggleVax(vaxItem.name)}
                      className="mt-0.5 size-4 rounded border-border text-primary focus:ring-primary"
                    />
                    <div className="min-w-0">
                      <span className="text-xs font-bold text-foreground block">
                        {vaxItem.name}
                      </span>
                      <span className="text-[11px] text-muted-foreground block">
                        {vaxItem.note}
                      </span>
                    </div>
                  </label>
                );
              })}

              {/* Custom Vaccines Added */}
              {customVaxes.map((cv) => (
                <div
                  key={cv.id}
                  className="flex items-center justify-between rounded-xl border border-primary/40 bg-primary/5 p-3 text-xs"
                >
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="size-4 text-primary shrink-0" />
                    <div>
                      <span className="font-bold text-foreground block">
                        {cv.name}
                      </span>
                      <span className="text-[11px] text-muted-foreground">
                        {t("lastVaxDate")}: {cv.date}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveCustomVax(cv.id)}
                    className="text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="size-4" />
                  </button>
                </div>
              ))}
            </div>

            {/* Add Custom Vaccine Input */}
            <div className="pt-2 flex flex-col gap-2 sm:flex-row">
              <input
                type="text"
                value={newVaxName}
                onChange={(e) => setNewVaxName(e.target.value)}
                placeholder={t("vaxNamePlaceholder")}
                className="w-full rounded-xl border border-border bg-background px-3.5 py-2 text-xs focus:border-primary focus:outline-none"
              />
              <button
                type="button"
                onClick={handleAddCustomVax}
                className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-xl border border-border bg-card px-4 py-2 text-xs font-semibold text-foreground hover:bg-muted"
              >
                <Plus className="size-3.5" />
                <span>{t("addCustomVax")}</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/10 p-4 text-xs text-amber-800 dark:text-amber-200 space-y-1">
            <span className="font-bold block flex items-center gap-1.5">
              <AlertCircle className="size-4 text-amber-600 dark:text-amber-400" />
              <span>{isEn ? "Recommended Care Tip" : "Lời khuyên từ Bác sĩ thú y"}</span>
            </span>
            <p className="leading-relaxed">
              {isEn
                ? "Vaccinating your pet helps prevent dangerous infectious diseases like rabies and parvo. You can find accredited clinics on PawCare to schedule their first shots."
                : "Tiêm phòng sớm giúp bảo vệ bé khỏi các bệnh nguy hiểm như Dại, Care, Parvo. Bạn có thể đặt lịch tại các phòng khám đạt chuẩn trên PawCare sau khi tạo hồ sơ."}
            </p>
          </div>
        )}

        {/* Additional Notes */}
        <div className="space-y-1.5 pt-2">
          <label
            htmlFor="pet-notes"
            className="text-xs font-bold uppercase tracking-wider text-muted-foreground"
          >
            {t("notes")}
          </label>
          <input
            id="pet-notes"
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder={t("notesPlaceholder")}
            className="w-full rounded-2xl border border-border bg-background px-4 py-3 text-sm transition focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20"
          />
        </div>
      </div>

      {/* Submit Button */}
      <div className="pt-2">
        <button
          type="submit"
          disabled={isSubmitting}
          className="flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-bold text-primary-foreground shadow-md transition hover:opacity-95 disabled:opacity-50"
        >
          {isSubmitting ? (
            <span>{isEn ? "Saving..." : "Đang lưu hồ sơ..."}</span>
          ) : (
            <>
              <Sparkles className="size-5" />
              <span>{t("submitBtn")}</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
}
