export interface ClinicDetail {
  id: string;
  name: string;
  address: string;
  district: string;
  phone: string;
  specialties: string[];
  languages: string[];
  is_24_7: boolean;
  verified: boolean;
  rating: number;
  reviewCount: number;
  description: string;
  services: {
    name: string;
    description: string;
    price_vnd: number;
    duration_minutes: number;
  }[];
  hours: {
    weekday: number;
    opens_at: string;
    closes_at: string;
    closed: boolean;
  }[];
}

const fallbackClinicsVi: ClinicDetail[] = [
  {
    id: "petcare-d1",
    name: "Phòng Khám Thú Y PetCare · Quận 1",
    address: "124 Nguyễn Thị Minh Khai, P. Bến Thành, Quận 1, TP.HCM",
    district: "Quận 1",
    phone: "028 3823 4567",
    specialties: ["Khám tổng quát", "Tiêm ngừa vắc-xin", "Cấp cứu 24/7", "Nha khoa thú cưng"],
    languages: ["Tiếng Việt", "English"],
    is_24_7: true,
    verified: true,
    rating: 4.9,
    reviewCount: 148,
    description:
      "Phòng khám thú y tiêu chuẩn quốc tế tại trung tâm Quận 1, trang bị đầy đủ máy xét nghiệm sinh hóa, máy X-quang kỹ thuật số và đội ngũ bác sĩ trực cấp cứu 24/7.",
    services: [
      {
        name: "Khám sức khỏe tổng quát & Tư vấn dinh dưỡng",
        description: "Kiểm tra toàn diện tim phổi, mắt, tai, răng miệng và tư vấn khẩu phần.",
        price_vnd: 150000,
        duration_minutes: 30,
      },
      {
        name: "Tiêm ngừa vắc-xin 4 bệnh mèo / 7 bệnh chó",
        description: "Vắc-xin chính hãng nhập khẩu, cấp sổ tiêm điện tử PawCare Passport.",
        price_vnd: 250000,
        duration_minutes: 20,
      },
      {
        name: "Tiêm phòng Dại (Rabies) có gắn tem kiểm dịch",
        description: "Bảo hộ 1 năm phòng chống dại cho chó mèo theo quy định thú y.",
        price_vnd: 80000,
        duration_minutes: 15,
      },
      {
        name: "Cạo vôi răng & Vệ sinh nha khoa bằng máy siêu âm",
        description: "Loại bỏ mảng bám ố vàng, khử mùi hôi miệng, chống viêm nướu.",
        price_vnd: 350000,
        duration_minutes: 45,
      },
      {
        name: "Cấp cứu khẩn cấp ngoài giờ (24/7 Emergency)",
        description: "Xử lý ngộ độc, khó thở, sốc nhiệt, tai nạn chấn thương.",
        price_vnd: 300000,
        duration_minutes: 60,
      },
    ],
    hours: [
      { weekday: 0, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 1, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 2, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 3, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 4, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 5, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 6, opens_at: "00:00", closes_at: "24:00", closed: false },
    ],
  },
  {
    id: "cholon-d5",
    name: "Bệnh Viện Thú Y Chợ Lớn · Quận 5",
    address: "88 Thuận Kiều, Phường 12, Quận 5, TP.HCM",
    district: "Quận 5",
    phone: "028 3955 8899",
    specialties: ["Phẫu thuật chỉnh hình & Xương", "Siêu âm chẩn đoán hình ảnh", "Điều trị nội trú"],
    languages: ["Tiếng Việt", "中文"],
    is_24_7: false,
    verified: true,
    rating: 4.8,
    reviewCount: 92,
    description:
      "Bệnh viện chuyên khoa sâu với hơn 15 năm kinh nghiệm điều trị các ca gãy xương, sỏi thận, mổ đẻ và phẫu thuật nội soi thú cưng tại khu vực Chợ Lớn.",
    services: [
      {
        name: "Chụp X-quang kỹ thuật số & Siêu âm màu Doppler",
        description: "Chẩn đoán chính xác chấn thương xương khớp và bệnh lý nội tạng.",
        price_vnd: 300000,
        duration_minutes: 40,
      },
      {
        name: "Phẫu thuật triệt sản chó mèo an toàn",
        description: "Phương pháp phẫu thuật đường mổ nhỏ, hạn chế đau và mau lành vết thương.",
        price_vnd: 600000,
        duration_minutes: 60,
      },
      {
        name: "Lưu viện điều trị nội trú & Chăm sóc hậu phẫu",
        description: "Chuồng cách ly vô trùng có sưởi ấm, theo dõi sinh hiệu 24/24.",
        price_vnd: 200000,
        duration_minutes: 1440,
      },
    ],
    hours: [
      { weekday: 0, opens_at: "08:00", closes_at: "18:00", closed: false },
      { weekday: 1, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 2, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 3, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 4, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 5, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 6, opens_at: "08:00", closes_at: "21:00", closed: false },
    ],
  },
  {
    id: "saigonpet-bt",
    name: "Phòng Khám Thú Y Sài Gòn Pet · Bình Thạnh",
    address: "312 Xô Viết Nghệ Tĩnh, Phường 25, Quận Bình Thạnh, TP.HCM",
    district: "Bình Thạnh",
    phone: "090 9123 456",
    specialties: ["Da liễu & Nấm ngứa", "Spa & Grooming làm đẹp", "Bác sĩ khám tận nhà"],
    languages: ["Tiếng Việt"],
    is_24_7: false,
    verified: true,
    rating: 4.7,
    reviewCount: 76,
    description:
      "Không gian chăm sóc thân thiện, không gây stress cho thú cưng. Chuyên khoa da liễu trị dứt điểm viêm da Demodex, nấm vảy gàu và dịch vụ đưa đón khám bệnh tận nhà.",
    services: [
      {
        name: "Xét nghiệm cạo da soi tươi & Phác đồ trị nấm",
        description: "Xác định chính xác loại vi khuẩn, nấm ký sinh trùng gây rụng lông.",
        price_vnd: 180000,
        duration_minutes: 30,
      },
      {
        name: "Tắm spa trị liệu, vệ sinh tai móng & Cắt tỉa lông tạo kiểu",
        description: "Sử dụng dầu tắm thảo dược dịu nhẹ và xông tinh dầu thư giãn.",
        price_vnd: 250000,
        duration_minutes: 60,
      },
      {
        name: "Bác sĩ thú y thăm khám & Tiêm chủng tại nhà",
        description: "Dành cho các bé mèo nhút nhát hoặc chủ nuôi bận rộn không tiện di chuyển.",
        price_vnd: 300000,
        duration_minutes: 45,
      },
    ],
    hours: [
      { weekday: 0, opens_at: "08:00", closes_at: "19:00", closed: false },
      { weekday: 1, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 2, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 3, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 4, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 5, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 6, opens_at: "07:30", closes_at: "20:30", closed: false },
    ],
  },
];

const fallbackClinicsEn: ClinicDetail[] = [
  {
    id: "petcare-d1",
    name: "PetCare Veterinary Clinic · District 1",
    address: "124 Nguyen Thi Minh Khai, Ben Thanh Ward, District 1, HCMC",
    district: "District 1",
    phone: "028 3823 4567",
    specialties: ["General Practice", "Vaccinations", "24/7 Emergency", "Veterinary Dentistry"],
    languages: ["English", "Vietnamese"],
    is_24_7: true,
    verified: true,
    rating: 4.9,
    reviewCount: 148,
    description:
      "International standard veterinary clinic in central District 1, fully equipped with in-house biochemistry lab, digital X-ray, and 24/7 emergency triage team.",
    services: [
      {
        name: "General Health Checkup & Dietary Consultation",
        description: "Comprehensive exam of heart, lungs, eyes, ears, teeth, and personalized diet plan.",
        price_vnd: 150000,
        duration_minutes: 30,
      },
      {
        name: "Feline 4-in-1 / Canine 7-in-1 Core Vaccination",
        description: "Authentic imported vaccines with automated PawCare digital passport issuance.",
        price_vnd: 250000,
        duration_minutes: 20,
      },
      {
        name: "Rabies Vaccination with Quarantine Stamp",
        description: "1-year certified rabies protection in compliance with veterinary regulations.",
        price_vnd: 80000,
        duration_minutes: 15,
      },
      {
        name: "Ultrasonic Dental Scaling & Oral Care",
        description: "Plaque and tartar removal, fresh breath treatment, and gingivitis prevention.",
        price_vnd: 350000,
        duration_minutes: 45,
      },
      {
        name: "After-Hours Emergency Triage (24/7)",
        description: "Rapid intervention for poisoning, respiratory distress, heatstroke, and trauma.",
        price_vnd: 300000,
        duration_minutes: 60,
      },
    ],
    hours: [
      { weekday: 0, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 1, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 2, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 3, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 4, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 5, opens_at: "00:00", closes_at: "24:00", closed: false },
      { weekday: 6, opens_at: "00:00", closes_at: "24:00", closed: false },
    ],
  },
  {
    id: "cholon-d5",
    name: "Cho Lon Veterinary Hospital · District 5",
    address: "88 Thuan Kieu, Ward 12, District 5, HCMC",
    district: "District 5",
    phone: "028 3955 8899",
    specialties: ["Orthopedic & Bone Surgery", "Color Doppler Ultrasound", "Inpatient Hospitalization"],
    languages: ["Vietnamese", "Chinese", "English"],
    is_24_7: false,
    verified: true,
    rating: 4.8,
    reviewCount: 92,
    description:
      "Specialized veterinary hospital with over 15 years of surgical experience in bone fractures, urinary stone removal, C-sections, and endoscopy in Cho Lon.",
    services: [
      {
        name: "Digital X-Ray & Color Doppler Ultrasound",
        description: "High-precision diagnosis of musculoskeletal trauma and internal organ conditions.",
        price_vnd: 300000,
        duration_minutes: 40,
      },
      {
        name: "Safe Spay & Neuter Minimally Invasive Surgery",
        description: "Small surgical incision, minimal discomfort, and expedited post-op healing.",
        price_vnd: 600000,
        duration_minutes: 60,
      },
      {
        name: "Inpatient Hospitalization & Intensive Care",
        description: "Climate-controlled sterile recovery units with 24-hour vital sign monitoring.",
        price_vnd: 200000,
        duration_minutes: 1440,
      },
    ],
    hours: [
      { weekday: 0, opens_at: "08:00", closes_at: "18:00", closed: false },
      { weekday: 1, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 2, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 3, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 4, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 5, opens_at: "08:00", closes_at: "21:00", closed: false },
      { weekday: 6, opens_at: "08:00", closes_at: "21:00", closed: false },
    ],
  },
  {
    id: "saigonpet-bt",
    name: "Saigon Pet Veterinary Clinic · Binh Thanh",
    address: "312 Xo Viet Nghe Tinh, Ward 25, Binh Thanh District, HCMC",
    district: "Binh Thanh",
    phone: "090 9123 456",
    specialties: ["Dermatology & Fungal Care", "Spa & Grooming", "House Call Vet"],
    languages: ["Vietnamese", "English"],
    is_24_7: false,
    verified: true,
    rating: 4.7,
    reviewCount: 76,
    description:
      "Fear-free, stress-reducing clinic environment. Specialized dermatology treatment for Demodex mites, dandruff fungus, and dedicated house call veterinary services.",
    services: [
      {
        name: "Skin Scraping Microscopy & Antifungal Protocol",
        description: "Accurate identification of bacterial and mite infestations causing alopecia.",
        price_vnd: 180000,
        duration_minutes: 30,
      },
      {
        name: "Therapeutic Medicated Bath, Ear/Nail Care & Grooming",
        description: "Gentle herbal cleansers and aromatherapy misting for ultimate comfort.",
        price_vnd: 250000,
        duration_minutes: 60,
      },
      {
        name: "House Call Veterinary Examination & In-Home Vaccination",
        description: "Ideal for timid cats or busy owners without transportation convenience.",
        price_vnd: 300000,
        duration_minutes: 45,
      },
    ],
    hours: [
      { weekday: 0, opens_at: "08:00", closes_at: "19:00", closed: false },
      { weekday: 1, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 2, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 3, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 4, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 5, opens_at: "07:30", closes_at: "20:30", closed: false },
      { weekday: 6, opens_at: "07:30", closes_at: "20:30", closed: false },
    ],
  },
];

export const fallbackClinics = fallbackClinicsVi;

export function getFallbackClinics(locale?: string): ClinicDetail[] {
  return locale === "en" ? fallbackClinicsEn : fallbackClinicsVi;
}

export function getFallbackClinicById(id: string, locale?: string): ClinicDetail | null {
  const list = getFallbackClinics(locale);
  return list.find((c) => c.id === id) ?? null;
}
