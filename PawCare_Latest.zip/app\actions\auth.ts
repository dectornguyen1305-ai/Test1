"use server";
import {redirect} from "next/navigation";
import {cookies, headers} from "next/headers";
import {z} from "zod";
import {createClient, isSupabaseConfigured} from "@/lib/supabase/server";
import {canAccessRole, homeForRole, parseRole, type AppRole} from "@/lib/auth/roles";

const credentials = z.object({
  email: z.string().trim().email(),
  password: z.string().min(8),
});

function safeNext(value: FormDataEntryValue | null, defaultTarget = "") {
  const path = typeof value === "string" ? value : "";
  return path.startsWith("/") && !path.startsWith("//") ? path : defaultTarget;
}

export async function signInAction(formData: FormData) {
  const locale = formData.get("locale") === "en" ? "en" : "vi";
  const context = formData.get("context") === "clinic" ? "clinic" : "owner";
  // Redirect to user profile/settings after signing in
  const defaultTarget = "/settings";

  const parsed = credentials.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    redirect(`/${locale}/sign-in?error=invalid&context=${context}`);
  }

  if (!isSupabaseConfigured()) {
    // In local development without Supabase credentials, sign in with a local dev session
    const cookieStore = await cookies();
    const devUser = {
      sub: context === "clinic" ? "dev-clinic-id" : "dev-owner-id",
      email: parsed.data.email,
      role: (context === "clinic" ? "clinic_admin" : "owner") as AppRole,
      name: parsed.data.email.split("@")[0],
    };
    cookieStore.set("pawcare_dev_session", JSON.stringify(devUser), {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });
    redirect(`/${locale}${safeNext(formData.get("next"), defaultTarget)}`);
  }

  const supabase = await createClient();
  const {error} = await supabase.auth.signInWithPassword({
    email: parsed.data.email,
    password: parsed.data.password,
  });

  if (error) {
    const msg = error.message.toLowerCase();
    if (msg.includes("email not confirmed")) {
      redirect(`/${locale}/sign-in?error=email_not_confirmed`);
    }
    if (msg.includes("invalid login credentials") || msg.includes("invalid credentials")) {
      redirect(`/${locale}/sign-in?error=invalid_credentials&context=${context}`);
    }
    redirect(`/${locale}/sign-in?error=invalid&context=${context}`);
  }

  redirect(`/${locale}${safeNext(formData.get("next"), defaultTarget)}`);
}

export async function signUpAction(formData: FormData) {
  const locale = formData.get("locale") === "en" ? "en" : "vi";
  const parsed = credentials
    .extend({name: z.string().trim().min(1).max(100)})
    .safeParse({
      email: formData.get("email"),
      password: formData.get("password"),
      name: formData.get("name"),
    });

  if (!parsed.success) {
    redirect(`/${locale}/sign-up?error=invalid`);
  }

  const intent = formData.get("context") === "clinic" ? "clinic" : "owner";

  if (!isSupabaseConfigured()) {
    // In local development without Supabase credentials, register as local dev user
    const cookieStore = await cookies();
    const devUser = {
      sub: "dev-owner-id",
      email: parsed.data.email,
      role: intent === "clinic" ? "clinic_admin" : "owner",
      name: parsed.data.name,
    };
    cookieStore.set("pawcare_dev_session", JSON.stringify(devUser), {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });
    // Direct to user profile after sign up
    redirect(`/${locale}/settings`);
  }

  const supabase = await createClient();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const callbackUrl = new URL("/auth/callback", siteUrl);
  callbackUrl.searchParams.set("locale", locale);
  if (intent === "clinic") callbackUrl.searchParams.set("context", "clinic");

  const {data, error} = await supabase.auth.signUp({
    email: parsed.data.email,
    password: parsed.data.password,
    options: {
      data: {
        full_name: parsed.data.name,
        onboarding_intent: intent,
      },
      emailRedirectTo: callbackUrl.toString(),
    },
  });

  if (error) {
    const msg = error.message.toLowerCase();
    if (msg.includes("already registered") || msg.includes("already in use") || msg.includes("exists")) {
      redirect(`/${locale}/sign-up?error=email_exists`);
    }
    redirect(`/${locale}/sign-up?error=invalid`);
  }

  if (data.session) {
    redirect(`/${locale}/settings`);
  }
  redirect(`/${locale}/sign-up?sent=1`);
}

export async function googleSignInAction(formData: FormData) {
  const locale = formData.get("locale") === "en" ? "en" : "vi";
  const context = formData.get("context") === "clinic" ? "clinic" : "owner";
  const next = safeNext(formData.get("next"));

  if (!isSupabaseConfigured()) {
    // When Supabase is not yet configured, simulate a Google/Gmail login for preview testing
    const cookieStore = await cookies();
    const devUser = {
      sub: "dev-google-user-id",
      email: "google-user@gmail.com",
      role: context === "clinic" ? "clinic_admin" : "owner",
      name: locale === "en" ? "Google Demo Account" : "Tài khoản Google Demo",
    };
    cookieStore.set("pawcare_dev_session", JSON.stringify(devUser), {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });

    if (next && next !== "/owner" && next !== "/clinic") {
      redirect(`/${locale}${next}`);
    }
    // Direct to user profile after sign in
    redirect(`/${locale}/settings`);
  }

  const supabase = await createClient();
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const callbackUrl = new URL("/auth/callback", siteUrl);
  callbackUrl.searchParams.set("locale", locale);
  if (context === "clinic") callbackUrl.searchParams.set("context", "clinic");
  if (next && next !== "/owner") callbackUrl.searchParams.set("next", next);

  const {data, error} = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: {
      redirectTo: callbackUrl.toString(),
      queryParams: {
        access_type: "offline",
        prompt: "select_account",
      },
    },
  });

  if (error || !data.url) {
    console.error("Google OAuth initialization error:", error);
    redirect(`/${locale}/sign-in?error=oauth_error`);
  }

  redirect(data.url);
}

export async function devSignInAction(formData: FormData) {
  const roleInput = formData.get("role");
  const role = parseRole(roleInput) ?? "owner";
  const locale = formData.get("locale") === "en" ? "en" : "vi";
  const next = safeNext(formData.get("next"));

  const cookieStore = await cookies();
  const roleNames: Record<AppRole, string> = {
    owner: locale === "en" ? "Demo Pet Owner" : "Chủ nuôi thử nghiệm",
    clinic_staff: locale === "en" ? "Demo Clinic Staff" : "Nhân viên phòng khám",
    clinic_admin: locale === "en" ? "Demo Clinic Manager" : "Quản lý phòng khám",
    platform_admin: locale === "en" ? "Demo Platform Admin" : "Quản trị viên nền tảng",
  };

  const devUser = {
    sub: `dev-${role}-id`,
    email: `dev-${role}@pawcare.local`,
    role,
    name: roleNames[role] || "Người dùng thử nghiệm",
  };

  cookieStore.set("pawcare_dev_session", JSON.stringify(devUser), {
    path: "/",
    httpOnly: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
  });

  if (next && next !== "/owner" && canAccessRole(role, [role])) {
    redirect(`/${locale}${next}`);
  }
  redirect(`/${locale}/settings`);
}

export async function signOutAction(formData?: FormData) {
  const cookieStore = await cookies();
  cookieStore.delete("pawcare_dev_session");
  cookieStore.set("pawcare_dev_session", "", {
    path: "/",
    maxAge: 0,
    expires: new Date(0),
    httpOnly: true,
    sameSite: "lax",
  });
  if (isSupabaseConfigured()) {
    try {
      const supabase = await createClient();
      await supabase.auth.signOut();
    } catch (e) {
      console.error("Sign out error:", e);
    }
  }

  let locale = "vi";
  if (formData && typeof formData.get === "function") {
    const l = formData.get("locale");
    if (l === "en" || l === "vi") locale = l;
  }
  if (locale === "vi") {
    try {
      const headerList = await headers();
      const referer = headerList.get("referer") || "";
      if (referer.includes("/en/") || referer.endsWith("/en")) {
        locale = "en";
      }
    } catch {}
  }
  redirect(`/${locale}/sign-in`);
}
