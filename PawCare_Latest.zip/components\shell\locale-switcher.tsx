"use client";
import Link from "next/link";
import { useLocale } from "next-intl";
import { usePathname } from "next/navigation";
import { useTranslations } from "next-intl";

export function LocaleSwitcher() {
  const locale = useLocale();
  const pathname = usePathname();
  const t = useTranslations("common");
  const path = pathname.replace(/^\/(vi|en)(?=\/|$)/, "");

  const handleSwitch = (code: string) => {
    if (typeof document !== "undefined") {
      document.cookie = `NEXT_LOCALE=${code}; path=/; max-age=31536000; SameSite=Lax`;
    }
  };

  return (
    <nav aria-label={t("language")} className="flex items-center gap-1 text-xs sm:text-sm shrink-0">
      {(["vi", "en"] as const).map((code) => {
        const href = `/${code}${path}`;
        const isCurrent = locale === code;
        return (
          <Link
            key={code}
            lang={code}
            href={href}
            onClick={() => handleSwitch(code)}
            aria-current={isCurrent ? "page" : undefined}
            className={`rounded-full px-2.5 py-1 text-xs font-semibold transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring sm:px-3 sm:py-1.5 sm:text-sm ${
              isCurrent
                ? "bg-secondary font-bold text-foreground shadow-2xs"
                : "text-muted-foreground hover:bg-secondary/60"
            }`}
          >
            {code.toUpperCase()}
          </Link>
        );
      })}
    </nav>
  );
}
