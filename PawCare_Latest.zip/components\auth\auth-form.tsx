"use client";

import { useState } from "react";
import { useSearchParams } from "next/navigation";
import { useLocale, useTranslations } from "next-intl";
import Link from "next/link";
import { Heart, Stethoscope, Building2, User, ShieldCheck } from "lucide-react";
import { googleSignInAction, signInAction, signUpAction } from "@/app/actions/auth";

export function AuthForm({ mode }: { mode: "sign-in" | "sign-up" }) {
  const [pending, setPending] = useState(false);
  const locale = useLocale();
  const t = useTranslations("auth");
  const common = useTranslations("common");
  const params = useSearchParams();
  const isSignup = mode === "sign-up";

  const initialContext = params.get("context") === "clinic" ? "clinic" : "owner";
  const [accountType, setAccountType] = useState<"owner" | "clinic">(initialContext);

  const action = async (formData: FormData) => {
    setPending(true);
    formData.set("locale", locale);
    formData.set("context", accountType);
    formData.set("next", params.get("next") ?? "");
    if (isSignup) await signUpAction(formData);
    else await signInAction(formData);
    setPending(false);
  };

  const errorCode = params.get("error");
  const getErrorMessage = (code: string | null) => {
    if (!code) return null;
    switch (code) {
      case "unavailable":
        return t("errorUnavailable");
      case "invalid_credentials":
        return t("errorInvalidCredentials");
      case "email_not_confirmed":
        return t("errorEmailNotConfirmed");
      case "email_exists":
        return t("errorEmailExists");
      case "oauth_error":
      case "oauth_failed":
        return t("errorOauth");
      default:
        return t("error");
    }
  };

  const isEn = locale === "en";

  return (
    <div className="grid gap-5">
      {/* Account Type Segment Switcher (Owner vs Clinic) */}
      <div className="space-y-1.5">
        <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
          {isEn ? "Select Account Role" : "Chọn đối tượng đăng nhập"}
        </label>
        <div className="grid grid-cols-2 gap-2 rounded-2xl border border-border bg-muted/40 p-1.5">
          <button
            type="button"
            onClick={() => setAccountType("owner")}
            className={`flex items-center justify-center gap-2 rounded-xl py-2.5 px-3 text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              accountType === "owner"
                ? "bg-card text-foreground shadow-xs ring-1 ring-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <User className="size-4 shrink-0 text-primary" />
            <span>{isEn ? "Pet Owner" : "Chủ nuôi"}</span>
          </button>
          <button
            type="button"
            onClick={() => setAccountType("clinic")}
            className={`flex items-center justify-center gap-2 rounded-xl py-2.5 px-3 text-xs sm:text-sm font-bold transition-all cursor-pointer ${
              accountType === "clinic"
                ? "bg-card text-foreground shadow-xs ring-1 ring-border"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Stethoscope className="size-4 shrink-0 text-primary" />
            <span>{isEn ? "Vet Clinic" : "Cơ sở y tế"}</span>
          </button>
        </div>
      </div>

      {/* Role Context Notification Banner */}
      <div
        className={`rounded-2xl border p-3.5 text-xs transition-colors ${
          accountType === "owner"
            ? "border-primary/20 bg-primary/5 text-foreground"
            : "border-blue-500/20 bg-blue-500/5 text-foreground"
        }`}
      >
        {accountType === "owner" ? (
          <div className="flex items-start gap-2.5">
            <Heart className="size-4 shrink-0 text-primary mt-0.5" />
            <div>
              <p className="font-bold text-primary">
                {isEn ? "Pet Owner Portal" : "Dành cho Chủ nuôi thú cưng"}
              </p>
              <p className="text-muted-foreground mt-0.5">
                {isEn
                  ? "Manage digital pet passports, vaccination history, and online appointments."
                  : "Quản lý sổ y bạ điện tử, tiêm chủng và đặt lịch khám cho các bé thú cưng."}
              </p>
            </div>
          </div>
        ) : (
          <div className="flex items-start gap-2.5">
            <Building2 className="size-4 shrink-0 text-blue-600 dark:text-blue-400 mt-0.5" />
            <div>
              <p className="font-bold text-blue-700 dark:text-blue-300">
                {isEn ? "Veterinary Medical Facility" : "Dành cho Phòng khám & Cơ sở y tế"}
              </p>
              <p className="text-muted-foreground mt-0.5">
                {isEn
                  ? "Access clinic dashboard, verify medical records, and triage emergency cases."
                  : "Cổng điều phối tiếp nhận bệnh án, cập nhật vắc-xin và cấp cứu thú cưng 24/7."}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Google Login / Sign Up Button */}
      <form
        action={async (data) => {
          setPending(true);
          data.set("locale", locale);
          data.set("context", accountType);
          data.set("next", params.get("next") ?? "");
          await googleSignInAction(data);
          setPending(false);
        }}
      >
        <button
          disabled={pending}
          className="flex w-full items-center justify-center gap-2.5 rounded-xl border border-border/80 bg-card py-2.5 px-4 text-sm font-medium shadow-xs transition hover:bg-accent focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring disabled:opacity-60 cursor-pointer"
          type="submit"
        >
          <span>
            {accountType === "clinic"
              ? isSignup
                ? isEn
                  ? "Sign up with Google (Clinic)"
                  : "Đăng ký cơ sở y tế với Google"
                : isEn
                ? "Sign in with Google (Clinic)"
                : "Đăng nhập bằng Google (Phòng khám)"
              : isSignup
              ? t("googleSignUp")
              : t("google")}
          </span>
          <svg className="h-4 w-4 shrink-0" viewBox="0 0 24 24" aria-hidden="true">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.15z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.27v3.15C3.25 21.35 7.33 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.27C.46 8.2 0 10.04 0 12s.46 3.8 1.27 5.42l4.01-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.25 2.65 1.27 6.58l4.01 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
            />
          </svg>
        </button>
      </form>

      {/* Divider */}
      <div className="flex items-center gap-3 text-xs text-muted-foreground">
        <span className="h-px flex-1 bg-border" />
        <span>{t("or")}</span>
        <span className="h-px flex-1 bg-border" />
      </div>

      {/* Email / Password Form */}
      <form action={action} className="grid gap-4">
        {/* Sign Up Fields tailored to Account Role */}
        {isSignup && accountType === "owner" && (
          <label className="grid gap-1.5 text-sm font-medium">
            {common("name")}
            <input
              name="name"
              autoComplete="name"
              required
              maxLength={100}
              placeholder={isEn ? "Jane Doe" : "Nguyễn Văn A"}
              className="rounded-xl border border-border bg-card px-4 py-3 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
            />
          </label>
        )}

        {isSignup && accountType === "clinic" && (
          <>
            <label className="grid gap-1.5 text-sm font-medium">
              {isEn ? "Clinic / Veterinary Hospital Name" : "Tên cơ sở y tế / Phòng khám"}
              <input
                name="name"
                autoComplete="organization"
                required
                maxLength={120}
                placeholder={
                  isEn ? "PetCare Veterinary Hospital" : "Bệnh viện Thú y PetCare Quận 1"
                }
                className="rounded-xl border border-border bg-card px-4 py-3 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </label>

            <label className="grid gap-1.5 text-sm font-medium">
              {isEn ? "Practice License / Tax ID (Optional)" : "Số giấy phép thú y / MST (Tùy chọn)"}
              <input
                name="license"
                placeholder={isEn ? "e.g. VET-2026-HCM-099" : "VD: 0312345678 hoặc CTY-2026/HCM"}
                className="rounded-xl border border-border bg-card px-4 py-3 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </label>
          </>
        )}

        <label className="grid gap-1.5 text-sm font-medium">
          {accountType === "clinic"
            ? isEn
              ? "Official Clinic Email"
              : "Email phòng khám / Bác sĩ"
            : common("email")}
          <input
            name="email"
            type="email"
            autoComplete="email"
            required
            placeholder={
              accountType === "clinic" ? "contact@petcare-clinic.vn" : "example@gmail.com"
            }
            className="rounded-xl border border-border bg-card px-4 py-3 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
          />
        </label>

        <label className="grid gap-1.5 text-sm font-medium">
          {common("password")}
          <input
            name="password"
            type="password"
            minLength={8}
            autoComplete={isSignup ? "new-password" : "current-password"}
            required
            placeholder="••••••••"
            className="rounded-xl border border-border bg-card px-4 py-3 outline-none focus:border-primary focus:ring-1 focus:ring-primary"
          />
          <span className="text-xs font-normal text-muted-foreground">{t("passwordHint")}</span>
        </label>

        {errorCode && (
          <div
            role="alert"
            className="rounded-xl border border-destructive/20 bg-destructive/10 p-3 text-sm text-destructive"
          >
            {getErrorMessage(errorCode)}
          </div>
        )}

        {params.get("sent") && (
          <div
            role="status"
            className="rounded-xl border border-primary/20 bg-primary/10 p-3 text-sm text-primary"
          >
            {t("checkEmail")}
          </div>
        )}

        <button
          disabled={pending}
          className="rounded-full bg-primary px-5 py-3 font-semibold text-primary-foreground shadow transition hover:opacity-90 disabled:opacity-60 cursor-pointer"
        >
          {pending
            ? common("loading")
            : isSignup
            ? accountType === "clinic"
              ? isEn
                ? "Register Clinic Account"
                : "Đăng ký Cơ sở y tế"
              : t("confirm")
            : accountType === "clinic"
            ? isEn
              ? "Sign in as Clinic"
              : "Đăng nhập Cơ sở y tế"
            : t("submit")}
        </button>
      </form>

      {/* Helpful note for Clinics wishing to verify */}
      {accountType === "clinic" && (
        <div className="rounded-2xl border border-border/80 bg-muted/30 p-3.5 text-xs text-muted-foreground flex items-center justify-between gap-2">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="size-4 text-primary shrink-0" />
            <span>
              {isEn
                ? "Want full verification badge on directory?"
                : "Muốn nhận huy hiệu chứng thực y tế trên danh bạ?"}
            </span>
          </span>
          <Link
            href={`/${locale}/clinic-apply`}
            className="font-bold text-primary hover:underline shrink-0"
          >
            {isEn ? "Apply verification →" : "Đăng ký thẩm định →"}
          </Link>
        </div>
      )}
    </div>
  );
}
