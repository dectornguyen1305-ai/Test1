"use client";

import { useState } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { Card } from "@/components/ui/card";
import {
  AlertTriangle,
  PhoneCall,
  HeartPulse,
  MapPin,
  Flame,
  ShieldAlert,
  ArrowRight,
  Info,
} from "lucide-react";
import { BackButton } from "@/components/ui/back-button";

interface FirstAidCategory {
  id: string;
  title: string;
  shortTitle: string;
  icon: typeof Flame;
  symptoms: string;
  steps: string[];
}

function getLocalizedFirstAid(locale: string): FirstAidCategory[] {
  const isEn = locale === "en";
  return [
    {
      id: "heatstroke",
      title: isEn ? "Heatstroke & Hyperthermia" : "Sốc nhiệt mùa hè (Heatstroke)",
      shortTitle: isEn ? "Heatstroke" : "Sốc nhiệt",
      icon: Flame,
      symptoms: isEn
        ? "Heavy persistent panting, dark red or purple gums, excessive drooling, unsteadiness, or collapse."
        : "Thở gấp gáp liên tục, lợi đỏ thẫm/tím tái, chảy nhiều dãi, đi loạng choạng hoặc ngất xỉu.",
      steps: isEn
        ? [
            "Immediately move pet to a shaded, well-ventilated area or air-conditioned room.",
            "Apply cool, damp towels (NEVER ice or freezing water) to paws, groin, and neck.",
            "Offer small sips of cool water; never force-feed water.",
            "Transport immediately to the nearest veterinary emergency clinic while keeping cool.",
          ]
        : [
            "Lập tức đưa bé vào nơi râm mát, thoáng gió hoặc phòng điều hòa nhẹ.",
            "Dùng khăn ẩm nước mát (KHÔNG dùng nước đá lạnh buốt) chườm lên vùng đệm bàn chân, nách và bẹn.",
            "Cho bé nhấp từng ngụm nhỏ nước mát, tuyệt đối không ép uống nhiều cùng lúc.",
            "Nhanh chóng chuyển đến cơ sở thú y gần nhất trong khi vẫn giữ mát trên đường đi.",
          ],
    },
    {
      id: "poisoning",
      title: isEn ? "Toxin / Poison Ingestion" : "Ngộ độc thức ăn / Hóa chất",
      shortTitle: isEn ? "Poisoning" : "Ngộ độc",
      icon: AlertTriangle,
      symptoms: isEn
        ? "Severe vomiting, tremors, foaming at the mouth, dilated pupils, lethargy, or weakness."
        : "Nôn mửa dữ dội, co giật, sùi bọt mép, giãn đồng tử, đi đứng không vững.",
      steps: isEn
        ? [
            "Safely remove the pet from any remaining toxic substances.",
            "Photograph or collect packaging, plants, or chemical labels for vet toxicological identification.",
            "DO NOT induce vomiting if caustic chemicals, acids, hydrocarbons, or sharp items were swallowed.",
            "Call emergency veterinary hotline immediately for guidance before transport.",
          ]
        : [
            "Cách ly ngay vật nuôi khỏi nguồn chất độc hại còn lại.",
            "Chụp ảnh hoặc giữ lại bao bì hóa chất/cây cỏ mà bé đã ăn để bác sĩ xác định độc tố.",
            "KHÔNG tự ý gây nôn nếu bé đã nuốt phải chất ăn mòn, axit, bazơ mạnh hoặc dầu mỡ.",
            "Gọi ngay cho đường dây nóng bác sĩ thú y để nhận chỉ dẫn chuyên môn trước khi di chuyển.",
          ],
    },
    {
      id: "choking",
      title: isEn ? "Choking / Foreign Body Obstruction" : "Hóc dị vật / Nghẹt thở",
      shortTitle: isEn ? "Choking" : "Hóc dị vật",
      icon: HeartPulse,
      symptoms: isEn
        ? "Pawing at mouth, silent retching, coughing, distress, blue or greyish gums."
        : "Cào cào miệng, ho khạc liên tục không ra tiếng, lợi chuyển sang màu tím xanh.",
      steps: isEn
        ? [
            "Carefully inspect the oral cavity with a flashlight to see if object is readily accessible.",
            "Do not probe blindly with fingers if the object is lodged deep, as this can push it further.",
            "Perform pet Heimlich maneuver: support chest from behind and deliver 4-5 firm upward thrusts below the ribs.",
            "Rush immediately to an emergency facility equipped with oxygen therapy.",
          ]
        : [
            "Mở miệng bé cẩn thận, dùng đèn soi xem dị vật có ở vị trí nhìn thấy rõ và dễ gắp không.",
            "Nếu dị vật ở quá sâu, không cố dùng tay móc vì dễ đẩy dị vật lọt sâu hơn.",
            "Áp dụng nghiệm pháp Heimlich cho thú cưng: Ôm ngang ngực bé từ phía sau, ép dứt khoát 4-5 lần vào vùng bụng dưới xương sườn.",
            "Khẩn trương đưa đến phòng khám có trang bị máy thở oxy.",
          ],
    },
    {
      id: "trauma",
      title: isEn ? "Bleeding & Trauma / Fractures" : "Chảy máu do chấn thương / Tai nạn",
      shortTitle: isEn ? "Trauma" : "Chấn thương",
      icon: ShieldAlert,
      symptoms: isEn
        ? "Open wounds, arterial or continuous bleeding, apparent fractures, crying upon contact."
        : "Vết rách da, chảy máu liên tục, gãy xương, đau đớn khi chạm vào.",
      steps: isEn
        ? [
            "Apply direct pressure using sterile gauze or clean cloth to stem bleeding.",
            "Bandage firmly without cutting off peripheral blood circulation.",
            "Place pet on a firm surface (board or folded blanket) to stabilize spinal alignment.",
            "Keep pet warm and calm during swift transport to emergency hospital.",
          ]
        : [
            "Dùng gạc y tế sạch hoặc khăn bông sạch ép trực tiếp lên vết thương để cầm máu.",
            "Băng ép vừa đủ chặt, không quấn quá nghẽn mạch máu ngoại vi.",
            "Đặt bé nằm trên mặt phẳng cứng (như tấm ván hoặc chăn gấp) để giữ cố định cột sống.",
            "Che chắn giữ ấm cơ thể trong khi vận chuyển đến bệnh viện cấp cứu.",
          ],
    },
  ];
}

function getLocalizedHotlines(locale: string) {
  const isEn = locale === "en";
  return [
    {
      name: isEn
        ? "24/7 Veterinary Emergency · District 1 Central"
        : "Cấp cứu Thú Y 24/7 · Khu vực Quận 1 & Trung tâm",
      phone: "028 3823 4567",
      address: isEn
        ? "124 Nguyen Thi Minh Khai, Ben Thanh Ward, District 1"
        : "124 Nguyễn Thị Minh Khai, P. Bến Thành, Quận 1",
    },
    {
      name: isEn
        ? "Cho Lon Emergency Vet Hospital · District 5"
        : "Bệnh viện Thú Y Cấp Cứu Chợ Lớn · Quận 5",
      phone: "028 3955 8899",
      address: isEn
        ? "88 Thuan Kieu, Ward 12, District 5"
        : "88 Thuận Kiều, Phường 12, Quận 5",
    },
    {
      name: isEn
        ? "Veterinary ICU & Trauma Center · Binh Thanh"
        : "Trung tâm Cấp Cứu & Hồi Sức Thú Y · Bình Thạnh",
      phone: "090 9123 456",
      address: isEn
        ? "312 Xo Viet Nghe Tinh, Ward 25, Binh Thanh"
        : "312 Xô Viết Nghệ Tĩnh, P. 25, Bình Thạnh",
    },
  ];
}

export function SosGuidance({ locale }: { locale: string }) {
  const tS = useTranslations("ownerSos");
  const categories = getLocalizedFirstAid(locale);
  const hotlines = getLocalizedHotlines(locale);

  const [activeCategory, setActiveCategory] = useState(categories[0].id);
  const selectedGuide = categories.find((c) => c.id === activeCategory) ?? categories[0];

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      {/* Top Navigation & Exit / Back button */}
      <div>
        <BackButton
          fallbackHref={`/${locale}/owner`}
          label={locale === "en" ? "Back to Dashboard" : "Quay lại Tổng quan"}
          variant="pill"
        />
      </div>

      {/* Top Banner Alert */}
      <div className="rounded-3xl border-2 border-destructive bg-destructive/10 p-6 md:p-8">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="grid size-12 shrink-0 place-items-center rounded-2xl bg-destructive text-destructive-foreground shadow-lg">
              <HeartPulse className="size-6 animate-pulse" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-bold uppercase tracking-wider text-destructive">
                {tS("badge")}
              </span>
              <h1 className="font-display text-2xl font-bold sm:text-3xl truncate">
                {tS("title")}
              </h1>
            </div>
          </div>

          <a
            href="tel:02838234567"
            className="inline-flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-destructive px-5 py-3 font-display text-sm font-bold text-destructive-foreground shadow-lg transition hover:brightness-110 sm:text-base"
          >
            <PhoneCall className="size-5 shrink-0" />
            <span>{tS("callNow")}</span>
          </a>
        </div>

        <p className="mt-4 text-xs leading-relaxed text-muted-foreground sm:text-sm">
          {tS("bannerDesc")}
        </p>
      </div>

      {/* 24/7 Emergency Hotlines */}
      <div>
        <h2 className="font-display text-lg font-bold flex items-center gap-2 sm:text-xl">
          <PhoneCall className="size-5 text-destructive shrink-0" />
          <span>{tS("hotlineSection")}</span>
        </h2>

        <div className="mt-3 grid gap-3 md:grid-cols-3">
          {hotlines.map((h, i) => (
            <Card key={i} className="flex flex-col justify-between p-4 border-destructive/20 h-full">
              <div>
                <p className="font-bold text-sm text-foreground">{h.name}</p>
                <p className="mt-1 flex items-start gap-1 text-xs text-muted-foreground">
                  <MapPin className="size-3.5 shrink-0 mt-0.5" />
                  <span>{h.address}</span>
                </p>
              </div>

              <a
                href={`tel:${h.phone.replace(/\s+/g, "")}`}
                className="mt-4 inline-flex items-center justify-center gap-2 rounded-xl bg-destructive/15 py-2 text-xs font-bold text-destructive transition hover:bg-destructive hover:text-destructive-foreground"
              >
                <PhoneCall className="size-3.5 shrink-0" />
                <span>{h.phone}</span>
              </a>
            </Card>
          ))}
        </div>
      </div>

      {/* Interactive First Aid Handbook */}
      <div>
        <h2 className="font-display text-lg font-bold flex items-center gap-2 sm:text-xl">
          <Info className="size-5 text-primary shrink-0" />
          <span>{tS("handbookTitle")}</span>
        </h2>
        <p className="text-xs text-muted-foreground mt-0.5">
          {tS("handbookSubtitle")}
        </p>

        {/* Category Selector Tabs */}
        <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {categories.map((c) => {
            const Icon = c.icon;
            const isSelected = c.id === selectedGuide.id;
            return (
              <button
                key={c.id}
                onClick={() => setActiveCategory(c.id)}
                className={`flex items-center gap-2 rounded-2xl border p-3 text-left transition ${
                  isSelected
                    ? "border-primary bg-primary/10 text-primary font-bold shadow-xs"
                    : "border-border bg-card text-muted-foreground hover:bg-muted/40"
                }`}
              >
                <Icon className="size-4 shrink-0" />
                <span className="text-xs truncate">{c.shortTitle}</span>
              </button>
            );
          })}
        </div>

        {/* Selected Guide Details */}
        <Card className="mt-4 p-6">
          <div className="flex items-center gap-2.5 border-b border-border pb-3">
            <selectedGuide.icon className="size-5 text-destructive shrink-0" />
            <h3 className="font-display text-lg font-bold">{selectedGuide.title}</h3>
          </div>

          <div className="mt-4 rounded-xl bg-muted/40 p-3.5 text-xs text-muted-foreground">
            <strong className="text-foreground">{tS("symptomsLabel")}: </strong>
            {selectedGuide.symptoms}
          </div>

          <div className="mt-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-primary">
              {tS("stepsLabel")}
            </h4>
            <ol className="mt-2.5 space-y-2 text-sm text-foreground">
              {selectedGuide.steps.map((step, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-xs font-bold text-primary mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed text-xs sm:text-sm">{step}</span>
                </li>
              ))}
            </ol>
          </div>
        </Card>
      </div>

      {/* Back to Home & Clinic Finder Link */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
        <Link
          href={`/${locale}/owner`}
          className="text-xs font-semibold text-muted-foreground hover:text-foreground"
        >
          {tS("backToOverview")}
        </Link>
        <Link
          href={`/${locale}/clinics`}
          className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-card px-4 py-2 text-xs font-bold text-primary transition hover:bg-accent"
        >
          <span>{tS("findClinicsMap")}</span>
          <ArrowRight className="size-3.5 shrink-0" />
        </Link>
      </div>
    </div>
  );
}
