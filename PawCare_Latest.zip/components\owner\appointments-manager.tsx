"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { Card } from "@/components/ui/card";
import {
  Calendar,
  Clock,
  MapPin,
  Plus,
  Stethoscope,
  CheckCircle2,
  CalendarCheck,
  Phone,
  X,
} from "lucide-react";
import { BackButton } from "@/components/ui/back-button";

interface Appointment {
  id: string;
  petName: string;
  clinicName: string;
  clinicAddress: string;
  clinicPhone: string;
  service: string;
  date: string;
  time: string;
  doctor: string;
  status: "confirmed" | "pending" | "completed" | "canceled";
  notes?: string;
}

function getLocalizedInitialAppointments(_locale: string): Appointment[] {
  return [];
}

export function AppointmentsManager({ locale }: { locale: string }) {
  const tOwner = useTranslations("owner");
  const tA = useTranslations("ownerAppointments");
  const common = useTranslations("common");

  const [appointments, setAppointments] = useState<Appointment[]>(() =>
    getLocalizedInitialAppointments(locale)
  );
  useEffect(() => {
    setAppointments(getLocalizedInitialAppointments(locale));
  }, [locale]);
  const [tab, setTab] = useState<"upcoming" | "history">("upcoming");
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowBookingModal(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // New booking form state
  const [form, setForm] = useState({
    petName: "",
    clinicName:
      locale === "en"
        ? "PetCare Veterinary Clinic · District 1"
        : "Phòng khám Thú Y PetCare · Quận 1",
    service: tA("serviceGeneral"),
    date: "2026-10-28",
    time: "10:00",
    notes: "",
  });

  const handleCreateAppointment = (e: React.FormEvent) => {
    e.preventDefault();
    const newApt: Appointment = {
      id: `apt-${Date.now()}`,
      petName: form.petName,
      clinicName: form.clinicName,
      clinicAddress:
        locale === "en"
          ? "124 Nguyen Thi Minh Khai, Ben Thanh Ward, District 1, HCMC"
          : "124 Nguyễn Thị Minh Khai, P. Bến Thành, Quận 1, TP.HCM",
      clinicPhone: "028 3823 4567",
      service: form.service,
      date: form.date,
      time: form.time,
      doctor: locale === "en" ? "Attending Veterinarian" : "Bác sĩ phụ trách ca",
      status: "confirmed",
      notes: form.notes,
    };
    setAppointments([newApt, ...appointments]);
    setShowBookingModal(false);
    setNotice(tA("bookingSuccess"));
    setTimeout(() => setNotice(null), 5000);
  };

  const handleCancel = (id: string) => {
    if (confirm(tA("cancelConfirm"))) {
      setAppointments(
        appointments.map((a) => (a.id === id ? { ...a, status: "canceled" } : a))
      );
    }
  };

  const upcoming = appointments.filter((a) => a.status === "confirmed" || a.status === "pending");
  const history = appointments.filter((a) => a.status === "completed" || a.status === "canceled");
  const displayList = tab === "upcoming" ? upcoming : history;

  return (
    <div className="space-y-6">
      {/* Top Navigation & Exit / Back button */}
      <div>
        <BackButton
          fallbackHref={`/${locale}/owner`}
          label={locale === "en" ? "Back to Dashboard" : "Quay lại Tổng quan"}
          variant="pill"
        />
      </div>

      {/* Header Row */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
              <CalendarCheck className="size-3.5 shrink-0" />
              {tA("badge")}
            </span>
          </div>
          <h1 className="mt-2 font-display text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl">
            {tOwner("bookings")} &amp; {tA("title")}
          </h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
            {tA("subtitle")}
          </p>
        </div>

        <button
          onClick={() => setShowBookingModal(true)}
          className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-xs font-semibold text-primary-foreground shadow-sm transition hover:opacity-90 sm:text-sm"
        >
          <Plus className="size-4 shrink-0" />
          <span>{tA("bookNew")}</span>
        </button>
      </div>

      {notice && (
        <div
          role="status"
          className="flex items-center justify-between rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4 text-xs font-medium text-emerald-800 dark:text-emerald-300 sm:text-sm"
        >
          <div className="flex items-center gap-2 min-w-0">
            <CheckCircle2 className="size-5 shrink-0" />
            <span className="truncate">{notice}</span>
          </div>
          <button onClick={() => setNotice(null)} className="p-1 hover:opacity-75 shrink-0">
            ✕
          </button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 border-b border-border pb-1">
        <button
          onClick={() => setTab("upcoming")}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition sm:text-sm ${
            tab === "upcoming"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          <span>{tA("tabUpcoming")}</span>
          <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs text-primary">
            {upcoming.length}
          </span>
        </button>
        <button
          onClick={() => setTab("history")}
          className={`flex items-center gap-2 border-b-2 px-4 py-2.5 text-xs font-bold transition sm:text-sm ${
            tab === "history"
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          <span>{tA("tabHistory")}</span>
          <span className="rounded-full bg-muted px-2 py-0.5 text-xs text-muted-foreground">
            {history.length}
          </span>
        </button>
      </div>

      {/* Appointment Cards List */}
      {!displayList.length ? (
        <Card className="p-8 text-center">
          <Calendar className="mx-auto size-12 text-muted-foreground/40" />
          <h3 className="mt-3 font-display text-lg font-bold">{tA("emptyTitle")}</h3>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
            {tab === "upcoming" ? tA("emptyUpcoming") : tA("emptyHistory")}
          </p>
          {tab === "upcoming" && (
            <button
              onClick={() => setShowBookingModal(true)}
              className="mt-4 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground sm:text-sm"
            >
              <Plus className="size-4 shrink-0" />
              <span>{tA("bookNow")}</span>
            </button>
          )}
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {displayList.map((apt) => {
            const isConfirmed = apt.status === "confirmed";
            const isPending = apt.status === "pending";
            const isCompleted = apt.status === "completed";
            const isCanceled = apt.status === "canceled";

            return (
              <Card key={apt.id} className="relative flex flex-col justify-between p-6">
                <div>
                  <div className="flex flex-col gap-2 border-b border-border pb-4 sm:flex-row sm:items-start sm:justify-between">
                    <div className="min-w-0">
                      <span className="text-xs font-semibold uppercase tracking-wider text-primary">
                        {tA("patient")}: 🐾 <strong>{apt.petName}</strong>
                      </span>
                      <h3 className="mt-1 font-display text-lg font-bold truncate">{apt.service}</h3>
                    </div>

                    <div className="shrink-0">
                      {isConfirmed && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                          <CheckCircle2 className="size-3.5 shrink-0" /> {tA("statusConfirmed")}
                        </span>
                      )}
                      {isPending && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                          <Clock className="size-3.5 shrink-0" /> {tA("statusPending")}
                        </span>
                      )}
                      {isCompleted && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-blue-100 px-3 py-1 text-xs font-bold text-blue-800 dark:bg-blue-950/60 dark:text-blue-300">
                          {tA("statusCompleted")}
                        </span>
                      )}
                      {isCanceled && (
                        <span className="inline-flex items-center gap-1 rounded-full bg-rose-100 px-3 py-1 text-xs font-bold text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
                          {tA("statusCanceled")}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 space-y-2.5 text-sm">
                    <div className="flex items-center gap-2.5 font-semibold text-foreground">
                      <Calendar className="size-4 text-primary shrink-0" />
                      <span className="truncate">
                        {new Intl.DateTimeFormat(locale, {
                          weekday: "short",
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                        }).format(new Date(apt.date))}
                        {" · "}
                        <strong className="text-primary">{apt.time}</strong>
                      </span>
                    </div>

                    <div className="flex items-start gap-2.5 text-xs text-muted-foreground">
                      <MapPin className="size-4 shrink-0 text-muted-foreground mt-0.5" />
                      <div className="min-w-0">
                        <p className="font-semibold text-foreground truncate">{apt.clinicName}</p>
                        <p className="line-clamp-2">{apt.clinicAddress}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 text-xs text-muted-foreground">
                      <Stethoscope className="size-4 shrink-0 text-muted-foreground" />
                      <span className="truncate">{tA("assignedDoctor")}: {apt.doctor}</span>
                    </div>

                    {apt.notes && (
                      <p className="mt-2 rounded-xl bg-muted/40 p-2.5 text-xs italic text-muted-foreground">
                        &quot;{apt.notes}&quot;
                      </p>
                    )}
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4 text-xs">
                  <a
                    href={`tel:${apt.clinicPhone.replace(/\s+/g, "")}`}
                    className="inline-flex items-center gap-1.5 font-semibold text-primary hover:underline shrink-0"
                  >
                    <Phone className="size-3.5 shrink-0" />
                    <span>{apt.clinicPhone}</span>
                  </a>

                  {(isConfirmed || isPending) && (
                    <div className="flex gap-2 shrink-0">
                      <button
                        onClick={() => handleCancel(apt.id)}
                        className="rounded-lg px-2.5 py-1.5 font-semibold text-destructive hover:bg-destructive/10"
                      >
                        {tA("cancel")}
                      </button>
                    </div>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Booking Modal Dialog */}
      {showBookingModal && (
        <div
          role="dialog"
          aria-modal="true"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowBookingModal(false);
          }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in"
        >
          <div className="w-full max-w-lg rounded-3xl border border-border bg-card p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-border pb-3">
              <h3 className="font-display text-xl font-bold">{tA("modalTitle")}</h3>
              <button
                type="button"
                onClick={() => setShowBookingModal(false)}
                className="inline-flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1 text-xs font-semibold text-secondary-foreground hover:bg-muted transition cursor-pointer"
                aria-label={locale === "en" ? "Exit booking" : "Thoát đặt lịch"}
              >
                <X className="size-3.5" />
                <span>{locale === "en" ? "Exit" : "Thoát"}</span>
              </button>
            </div>

            <form onSubmit={handleCreateAppointment} className="mt-4 space-y-4">
              <div>
                <label className="text-xs font-bold text-foreground">{tA("selectPet")}</label>
                <input
                  type="text"
                  required
                  placeholder={locale === "en" ? "Enter your pet's name..." : "Nhập tên thú cưng của bạn..."}
                  value={form.petName}
                  onChange={(e) => setForm({ ...form, petName: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-foreground">{tA("selectClinic")}</label>
                <select
                  value={form.clinicName}
                  onChange={(e) => setForm({ ...form, clinicName: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
                >
                  <option value={locale === "en" ? "PetCare Veterinary Clinic · District 1" : "Phòng khám Thú Y PetCare · Quận 1"}>
                    {locale === "en" ? "PetCare Veterinary Clinic · District 1 (1.2 km)" : "Phòng khám Thú Y PetCare · Quận 1 (1.2 km)"}
                  </option>
                  <option value={locale === "en" ? "Cho Lon Veterinary Hospital · District 5" : "Bệnh viện Thú Y Chợ Lớn · Quận 5"}>
                    {locale === "en" ? "Cho Lon Veterinary Hospital · District 5 (2.7 km)" : "Bệnh viện Thú Y Chợ Lớn · Quận 5 (2.7 km)"}
                  </option>
                  <option value={locale === "en" ? "Saigon Pet Veterinary Clinic · Binh Thanh" : "Phòng khám Thú Y Sài Gòn · Bình Thạnh"}>
                    {locale === "en" ? "Saigon Pet Veterinary Clinic · Binh Thanh (4.5 km)" : "Phòng khám Thú Y Sài Gòn · Bình Thạnh (4.5 km)"}
                  </option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-foreground">{tA("selectService")}</label>
                <select
                  value={form.service}
                  onChange={(e) => setForm({ ...form, service: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
                >
                  <option value={tA("serviceGeneral")}>{tA("serviceGeneral")}</option>
                  <option value={tA("serviceVaccine")}>{tA("serviceVaccine")}</option>
                  <option value={tA("serviceDental")}>{tA("serviceDental")}</option>
                  <option value={tA("serviceDermatology")}>{tA("serviceDermatology")}</option>
                  <option value={tA("serviceUltrasound")}>{tA("serviceUltrasound")}</option>
                  <option value={tA("serviceGrooming")}>{tA("serviceGrooming")}</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-foreground">{tA("date")}</label>
                  <input
                    type="date"
                    required
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-foreground">{tA("timeSlot")}</label>
                  <select
                    value={form.time}
                    onChange={(e) => setForm({ ...form, time: e.target.value })}
                    className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
                  >
                    <option value="08:30">08:30 - {tA("timeMorning")}</option>
                    <option value="09:30">09:30 - {tA("timeMorning")}</option>
                    <option value="10:30">10:30 - {tA("timeMorning")}</option>
                    <option value="14:00">14:00 - {tA("timeAfternoon")}</option>
                    <option value="15:30">15:30 - {tA("timeAfternoon")}</option>
                    <option value="17:00">17:00 - {tA("timeEvening")}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-foreground">
                  {tA("notesLabel")}
                </label>
                <textarea
                  rows={2}
                  value={form.notes}
                  placeholder={tA("notesPlaceholder")}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2 text-sm outline-none focus:border-primary"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBookingModal(false)}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-xl border border-border py-2.5 text-sm font-semibold hover:bg-muted transition cursor-pointer"
                >
                  <X className="size-4 text-muted-foreground" />
                  <span>{locale === "en" ? "Exit / Cancel" : "Thoát / Huỷ"}</span>
                </button>
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-primary py-2.5 text-sm font-semibold text-primary-foreground shadow hover:opacity-90"
                >
                  {tA("confirmBooking")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
