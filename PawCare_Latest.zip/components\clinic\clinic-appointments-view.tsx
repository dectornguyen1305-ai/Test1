"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useTranslations } from "next-intl";
import { Card } from "@/components/ui/card";
import {
  Phone,
  CheckCircle2,
  Stethoscope,
  Syringe,
  ChevronRight,
  UserCheck,
} from "lucide-react";
import { BackButton } from "@/components/ui/back-button";

interface ClinicAppointment {
  id: string;
  time: string;
  date: string;
  petName: string;
  species: "dog" | "cat" | "other";
  breed: string;
  ownerName: string;
  ownerPhone: string;
  service: string;
  vetName: string;
  status: "waiting" | "in_progress" | "completed" | "canceled";
  notes?: string;
}

function getLocalizedClinicAppointments(_locale: string): ClinicAppointment[] {
  return [];
}

export function ClinicAppointmentsView({ locale }: { locale: string }) {
  const tC = useTranslations("clinicAppointments");

  const [appointments, setAppointments] = useState<ClinicAppointment[]>(() =>
    getLocalizedClinicAppointments(locale)
  );
  useEffect(() => {
    setAppointments(getLocalizedClinicAppointments(locale));
  }, [locale]);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [notice, setNotice] = useState<string | null>(null);

  const handleUpdateStatus = (id: string, newStatus: ClinicAppointment["status"]) => {
    setAppointments(
      appointments.map((a) => (a.id === id ? { ...a, status: newStatus } : a))
    );
    const label =
      newStatus === "in_progress"
        ? tC("statusMovedInProgress")
        : newStatus === "completed"
        ? tC("statusMovedCompleted")
        : tC("statusUpdated");
    setNotice(label);
    setTimeout(() => setNotice(null), 4000);
  };

  const filtered = appointments.filter((a) => {
    if (filterStatus === "all") return true;
    return a.status === filterStatus;
  });

  const countWaiting = appointments.filter((a) => a.status === "waiting").length;
  const countInProgress = appointments.filter((a) => a.status === "in_progress").length;
  const countCompleted = appointments.filter((a) => a.status === "completed").length;

  return (
    <div className="space-y-6">
      {/* Top Navigation & Exit / Back button */}
      <div>
        <BackButton
          fallbackHref={`/${locale}/clinic`}
          label={locale === "en" ? "Back to Clinic Portal" : "Quay lại Cổng phòng khám"}
          variant="pill"
        />
      </div>

      {/* Top Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
            <Stethoscope className="size-3.5 shrink-0" />
            {tC("badge")}
          </span>
          <h1 className="mt-2 font-display text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl">
            {tC("title")}
          </h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
            {tC("subtitle")}
          </p>
        </div>

        <Link
          href={`/${locale}/clinic/patients`}
          className="inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-xs font-semibold text-primary-foreground shadow-sm transition hover:opacity-90 sm:text-sm"
        >
          <Syringe className="size-4 shrink-0" />
          <span>{tC("enterVax")}</span>
        </Link>
      </div>

      {notice && (
        <div className="flex items-center justify-between rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-3.5 text-xs font-medium text-emerald-800 dark:text-emerald-300 sm:text-sm">
          <div className="flex items-center gap-2 min-w-0">
            <CheckCircle2 className="size-4 shrink-0" />
            <span className="truncate">{notice}</span>
          </div>
          <button onClick={() => setNotice(null)} className="p-1 hover:opacity-75 shrink-0">
            ✕
          </button>
        </div>
      )}

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card className="p-4 min-w-0">
          <p className="text-xs text-muted-foreground font-medium leading-tight truncate">
            {tC("totalToday")}
          </p>
          <p className="mt-1 font-display text-2xl font-bold text-foreground">
            {appointments.length}
          </p>
        </Card>
        <Card className="p-4 border-amber-500/20 bg-amber-500/5 min-w-0">
          <p className="text-xs text-amber-800 dark:text-amber-400 font-medium leading-tight truncate">
            {tC("waiting")}
          </p>
          <p className="mt-1 font-display text-2xl font-bold text-amber-700 dark:text-amber-300">
            {countWaiting}
          </p>
        </Card>
        <Card className="p-4 border-primary/20 bg-primary/5 min-w-0">
          <p className="text-xs text-primary font-medium leading-tight truncate">
            {tC("inProgress")}
          </p>
          <p className="mt-1 font-display text-2xl font-bold text-primary">{countInProgress}</p>
        </Card>
        <Card className="p-4 border-emerald-500/20 bg-emerald-500/5 min-w-0">
          <p className="text-xs text-emerald-800 dark:text-emerald-400 font-medium leading-tight truncate">
            {tC("completed")}
          </p>
          <p className="mt-1 font-display text-2xl font-bold text-emerald-700 dark:text-emerald-300">
            {countCompleted}
          </p>
        </Card>
      </div>

      {/* Filter Row */}
      <div className="flex flex-col gap-3 border-b border-border pb-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => setFilterStatus("all")}
            className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
              filterStatus === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {tC("allFilter")} ({appointments.length})
          </button>
          <button
            onClick={() => setFilterStatus("waiting")}
            className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
              filterStatus === "waiting"
                ? "bg-amber-600 text-white"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {tC("waitingFilter")} ({countWaiting})
          </button>
          <button
            onClick={() => setFilterStatus("in_progress")}
            className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
              filterStatus === "in_progress"
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {tC("inProgressFilter")} ({countInProgress})
          </button>
          <button
            onClick={() => setFilterStatus("completed")}
            className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
              filterStatus === "completed"
                ? "bg-emerald-600 text-white"
                : "bg-muted text-muted-foreground hover:bg-muted/80"
            }`}
          >
            {tC("completedFilter")} ({countCompleted})
          </button>
        </div>

        <span className="text-xs text-muted-foreground shrink-0">
          {tC("dutyDate")}: <strong>{new Intl.DateTimeFormat(locale, { dateStyle: "long" }).format(new Date("2026-10-21"))}</strong>
        </span>
      </div>

      {/* Appointment List Table / Cards */}
      <div className="space-y-3.5">
        {filtered.length === 0 ? (
          <Card className="p-8 text-center border-dashed">
            <p className="text-sm font-semibold text-muted-foreground">
              {locale === "en" ? "No appointments scheduled today" : "Chưa có ca hẹn khám nào trong ngày"}
            </p>
          </Card>
        ) : (
          filtered.map((apt) => {
          const isWaiting = apt.status === "waiting";
          const isInProgress = apt.status === "in_progress";
          const isCompleted = apt.status === "completed";

          return (
            <Card
              key={apt.id}
              className={`p-5 transition ${
                isInProgress
                  ? "border-primary/50 bg-primary/5 ring-1 ring-primary/20"
                  : isWaiting
                  ? "border-border hover:border-border/80"
                  : "opacity-80"
              }`}
            >
              <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                <div className="flex items-start gap-3.5 min-w-0">
                  <div className="grid size-12 shrink-0 place-items-center rounded-2xl bg-secondary text-2xl font-bold">
                    {apt.species === "cat" ? "🐱" : "🐶"}
                  </div>

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-sm font-bold text-primary">
                        {apt.time}
                      </span>
                      <span className="text-muted-foreground">·</span>
                      <h3 className="font-bold text-foreground truncate">
                        {apt.petName} ({apt.breed})
                      </h3>
                      {isWaiting && (
                        <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
                          {tC("statusWaiting")}
                        </span>
                      )}
                      {isInProgress && (
                        <span className="rounded-full bg-primary/20 px-2.5 py-0.5 text-xs font-semibold text-primary">
                          {tC("statusInProgress")}
                        </span>
                      )}
                      {isCompleted && (
                        <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-semibold text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
                          {tC("statusCompleted")}
                        </span>
                      )}
                    </div>

                    <p className="mt-1 text-sm font-semibold text-foreground">
                      {apt.service}
                    </p>

                    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span>{tC("owner")}: <strong>{apt.ownerName}</strong></span>
                      <a
                        href={`tel:${apt.ownerPhone.replace(/\s+/g, "")}`}
                        className="inline-flex items-center gap-1 text-primary hover:underline"
                      >
                        <Phone className="size-3" />
                        <span>{apt.ownerPhone}</span>
                      </a>
                      <span>{tC("attendingVet")}: <strong>{apt.vetName}</strong></span>
                    </div>

                    {apt.notes && (
                      <p className="mt-2 rounded-xl bg-amber-500/10 p-2 text-xs text-amber-900 dark:text-amber-200">
                        <strong>{tC("noticeLabel")}:</strong> {apt.notes}
                      </p>
                    )}
                  </div>
                </div>

                {/* Status action buttons */}
                <div className="flex flex-wrap items-center gap-2 shrink-0 sm:flex-nowrap">
                  {isWaiting && (
                    <button
                      onClick={() => handleUpdateStatus(apt.id, "in_progress")}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground shadow-xs transition hover:opacity-90"
                    >
                      <UserCheck className="size-3.5 shrink-0" />
                      <span>{tC("startExam")}</span>
                    </button>
                  )}
                  {isInProgress && (
                    <button
                      onClick={() => handleUpdateStatus(apt.id, "completed")}
                      className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3 py-2 text-xs font-bold text-white shadow-xs transition hover:bg-emerald-700"
                    >
                      <CheckCircle2 className="size-3.5 shrink-0" />
                      <span>{tC("finishExam")}</span>
                    </button>
                  )}
                  <Link
                    href={`/${locale}/clinic/patients`}
                    className="inline-flex items-center gap-1 rounded-xl border border-border px-3 py-2 text-xs font-semibold transition hover:bg-muted"
                  >
                    <span>{tC("viewPassport")}</span>
                    <ChevronRight className="size-3.5 shrink-0" />
                  </Link>
                </div>
              </div>
            </Card>
          );
        })
      )}
      </div>
    </div>
  );
}
