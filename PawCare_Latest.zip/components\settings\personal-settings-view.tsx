"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useLocale, useTranslations } from "next-intl";
import {
  User,
  Heart,
  Lock,
  CreditCard,
  Palette,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Plus,
  Eye,
  EyeOff,
  Sun,
  Moon,
  Laptop,
  Check,
  Trash2,
  ExternalLink,
  LogOut,
  Smartphone,
  Mail,
} from "lucide-react";
import { Card } from "@/components/ui/card";
import { BackButton } from "@/components/ui/back-button";
import { signOutAction } from "@/app/actions/auth";

interface PersonalSettingsProps {
  initialProfile?: {
    full_name?: string;
    phone?: string;
    email?: string;
    gender?: string;
    birthDate?: string;
    city?: string;
  };
  role?: string;
}

export function PersonalSettingsView({
  initialProfile,
  role = "owner",
}: PersonalSettingsProps) {
  const locale = useLocale();
  const isEn = locale === "en";

  // Tab State
  const [activeTab, setActiveTab] = useState<
    "profile" | "pets" | "password" | "billing" | "display" | "privacy"
  >("profile");

  // Sync hash from URL if present (e.g. #password, #pets, #billing, #display)
  useEffect(() => {
    if (typeof window !== "undefined") {
      const hash = window.location.hash.replace("#", "");
      if (["profile", "pets", "password", "billing", "display", "privacy"].includes(hash)) {
        setActiveTab(hash as any);
      }
    }
  }, []);

  // Notification Toast State
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 4000);
  };

  // Sign out state & handler
  const [isSigningOut, setIsSigningOut] = useState(false);
  const handleSignOut = async (e: React.FormEvent | React.MouseEvent) => {
    e.preventDefault();
    if (isSigningOut) return;
    setIsSigningOut(true);
    try {
      await fetch(`/api/auth/sign-out?locale=${locale}`, { method: "POST" }).catch(() => {});
      const fd = new FormData();
      fd.set("locale", locale);
      await signOutAction(fd).catch(() => {});
    } catch {
    } finally {
      window.location.href = `/${locale}/sign-in`;
    }
  };

  // --- Profile State ---
  const [profile, setProfile] = useState({
    fullName: initialProfile?.full_name || (isEn ? "Nguyen Van A" : "Nguyễn Văn A"),
    phone: initialProfile?.phone || "0908 123 456",
    email: initialProfile?.email || "owner@pawcare.vn",
    gender: initialProfile?.gender || "male",
    birthDate: initialProfile?.birthDate || "1994-06-15",
    city: initialProfile?.city || (isEn ? "Ho Chi Minh City" : "TP. Hồ Chí Minh"),
  });

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    showToast(isEn ? "Personal profile updated successfully!" : "Đã lưu cập nhật thông tin cá nhân thành công!");
  };

  // --- Pet List State (loaded from localStorage or empty) ---
  const [pets, setPets] = useState<
    Array<{
      id: string;
      name: string;
      species: string;
      breed: string;
      birthDate: string;
      weightKg: number;
      microchip: string;
      vaxCount: number;
      status: string;
    }>
  >([]);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const loadPetsFromStorage = () => {
        try {
          const raw = localStorage.getItem("pawcare-user-pets");
          if (raw) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              setPets(
                parsed.map((p: any) => ({
                  id: p.id || `pet-${Math.random()}`,
                  name: p.name,
                  species: p.species || "dog",
                  breed: p.breed || (isEn ? "Companion" : "Thú cưng"),
                  birthDate: p.birthDate || "",
                  weightKg: p.weightKg || 4.5,
                  microchip: p.microchip || "VN-PC-000000",
                  vaxCount: p.vaccinations?.length ?? p.vaxCount ?? 0,
                  status: isEn ? "Verified" : "Đã xác thực",
                }))
              );
            }
          }
        } catch {}
      };

      loadPetsFromStorage();
      const handleUpdated = () => loadPetsFromStorage();
      window.addEventListener("pawcare-pets-updated", handleUpdated);
      return () => window.removeEventListener("pawcare-pets-updated", handleUpdated);
    }
  }, [isEn]);

  // --- Password Change State ---
  const [passwords, setPasswords] = useState({
    current: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [passwordError, setPasswordError] = useState<string | null>(null);

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError(null);
    if (passwords.newPassword.length < 8) {
      setPasswordError(
        isEn
          ? "New password must be at least 8 characters long."
          : "Mật khẩu mới phải có tối thiểu 8 ký tự."
      );
      return;
    }
    if (passwords.newPassword !== passwords.confirmPassword) {
      setPasswordError(
        isEn ? "New password confirmation does not match." : "Xác nhận mật khẩu mới không trùng khớp."
      );
      return;
    }
    setPasswords({ current: "", newPassword: "", confirmPassword: "" });
    showToast(isEn ? "Password changed successfully!" : "Đổi mật khẩu tài khoản thành công!");
  };

  // --- Payment Methods State ---
  const [paymentMethods, setPaymentMethods] = useState([
    {
      id: "pm-01",
      type: "card",
      brand: "Visa",
      last4: "4242",
      expiry: "08/28",
      isDefault: true,
    },
    {
      id: "pm-02",
      type: "momo",
      brand: "Ví MoMo",
      account: "0908 ••• 456",
      isDefault: false,
    },
  ]);

  // --- Website Display & Accessibility Settings State ---
  const [themeMode, setThemeMode] = useState<"light" | "dark" | "system">("light");
  const [fontSize, setFontSize] = useState<"sm" | "md" | "lg">("md");
  const [contrastMode, setContrastMode] = useState<"normal" | "high">("normal");

  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedTheme = (localStorage.getItem("pawcare-theme") as any) || "light";
      const savedFont = (localStorage.getItem("pawcare-font-size") as any) || "md";
      const savedContrast = (localStorage.getItem("pawcare-contrast") as any) || "normal";
      setThemeMode(savedTheme);
      setFontSize(savedFont);
      setContrastMode(savedContrast);
    }
  }, []);

  const changeTheme = (mode: "light" | "dark" | "system") => {
    setThemeMode(mode);
    localStorage.setItem("pawcare-theme", mode);
    const isDark =
      mode === "dark" ||
      (mode === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    if (isDark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    showToast(
      isEn
        ? `Applied ${mode === "dark" ? "Dark Theme" : mode === "light" ? "Light Theme" : "System Theme"}`
        : `Đã áp dụng giao diện ${mode === "dark" ? "Theme Tối" : mode === "light" ? "Theme Sáng" : "Theo hệ thống"}`
    );
  };

  const changeFontSize = (size: "sm" | "md" | "lg") => {
    setFontSize(size);
    localStorage.setItem("pawcare-font-size", size);
    document.documentElement.setAttribute("data-font-size", size);
    showToast(
      isEn
        ? `Font size set to ${size === "sm" ? "Compact" : size === "lg" ? "Large" : "Default"}`
        : `Cỡ chữ website đã đổi sang: ${size === "sm" ? "Nhỏ" : size === "lg" ? "Lớn" : "Tiêu chuẩn"}`
    );
  };

  const changeContrast = (contrast: "normal" | "high") => {
    setContrastMode(contrast);
    localStorage.setItem("pawcare-contrast", contrast);
    document.documentElement.setAttribute("data-contrast", contrast);
    showToast(
      isEn
        ? `Contrast set to ${contrast === "high" ? "High Contrast" : "Standard"}`
        : `Độ tương phản website đã đổi sang: ${contrast === "high" ? "Tương phản cao" : "Tiêu chuẩn"}`
    );
  };

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* Top Back Navigation */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BackButton
            fallbackHref={`/${locale}`}
            label={isEn ? "Back to Home" : "Quay về Trang chủ"}
            variant="pill"
          />
          <Link
            href={role === "owner" ? `/${locale}/owner` : `/${locale}/clinic`}
            className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-semibold rounded-full bg-secondary/80 px-3.5 py-1.5 text-secondary-foreground hover:bg-secondary border border-border/60 shadow-2xs hover:shadow-xs transition shrink-0"
          >
            <span>{role === "owner" ? (isEn ? "Dashboard" : "Tổng quan") : (isEn ? "Clinic Portal" : "Cổng phòng khám")}</span>
          </Link>
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden sm:inline-flex items-center gap-1 rounded-full bg-primary/10 px-3 py-1 text-xs font-bold text-primary">
            <ShieldCheck className="size-3.5" />
            {isEn ? "PawCare ID Verified" : "Tài khoản đã xác thực"}
          </span>
        </div>
      </div>

      {/* Header Info */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-border pb-5">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl text-foreground">
            {isEn ? "Personal Account Settings" : "Cài đặt tài khoản cá nhân"}
          </h1>
          <p className="mt-1 text-xs text-muted-foreground sm:text-sm">
            {isEn
              ? "Manage your profile, pets, security password, billing methods, and dark theme display."
              : "Quản lý hồ sơ, danh sách thú cưng, mật khẩu bảo mật, phương thức thanh toán và giao diện website."}
          </p>
        </div>
      </div>

      {/* Notification Toast */}
      {toastMessage && (
        <div
          role="status"
          className="flex items-center gap-2.5 rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4 text-xs font-semibold text-emerald-800 dark:text-emerald-300 sm:text-sm animate-in fade-in"
        >
          <CheckCircle2 className="size-5 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Settings Navigation Tabs */}
      <div className="flex gap-2 overflow-x-auto border-b border-border pb-1">
        {[
          { id: "profile", label: isEn ? "Personal Profile" : "Hồ sơ cá nhân", icon: User },
          { id: "pets", label: isEn ? "Pet Information" : "Thông tin thú cưng", icon: Heart },
          { id: "password", label: isEn ? "Change Password" : "Thay đổi mật khẩu", icon: Lock },
          { id: "billing", label: isEn ? "Payment Methods" : "Phương thức thanh toán", icon: CreditCard },
          { id: "display", label: isEn ? "Theme & Display" : "Cài đặt website", icon: Palette },
        ].map((tab) => {
          const Icon = tab.icon;
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex shrink-0 items-center gap-2 border-b-2 px-3.5 py-2.5 text-xs font-bold transition sm:text-sm cursor-pointer ${
                isSelected
                  ? "border-primary text-primary bg-primary/5 rounded-t-xl"
                  : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/30 rounded-t-xl"
              }`}
            >
              <Icon className="size-4 shrink-0" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: Personal Profile (Hồ sơ cá nhân) */}
      {activeTab === "profile" && (
        <Card className="p-6 md:p-8 space-y-6">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center justify-between border-b border-border pb-5">
            <div className="flex items-center gap-4">
              <div className="grid size-16 shrink-0 place-items-center rounded-full bg-primary text-2xl font-bold text-primary-foreground shadow-sm">
                {profile.fullName.charAt(0).toUpperCase()}
              </div>
              <div>
                <h2 className="font-display text-xl font-bold">{profile.fullName}</h2>
                <p className="text-xs text-muted-foreground">{profile.email}</p>
                <span className="mt-1 inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-600 dark:text-emerald-400">
                  <Check className="size-3" />
                  {isEn ? "Email Verified" : "Email đã xác thực"}
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => showToast(isEn ? "Avatar selection opened" : "Mở chức năng đổi ảnh đại diện")}
              className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-4 py-2 text-xs font-semibold hover:bg-muted shadow-2xs"
            >
              <User className="size-3.5 text-primary" />
              <span>{isEn ? "Change Avatar" : "Đổi ảnh đại diện"}</span>
            </button>
          </div>

          <form onSubmit={handleSaveProfile} className="grid gap-5 sm:grid-cols-2">
            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "Full Name" : "Họ và tên"}
              </label>
              <input
                required
                value={profile.fullName}
                onChange={(e) => setProfile({ ...profile, fullName: e.target.value })}
                className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "Phone Number" : "Số điện thoại"}
              </label>
              <input
                type="tel"
                required
                value={profile.phone}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "Email Address" : "Địa chỉ Email"}
              </label>
              <input
                type="email"
                disabled
                value={profile.email}
                className="mt-1 w-full rounded-xl border border-border bg-muted/50 px-3.5 py-2.5 text-sm text-muted-foreground outline-none opacity-80"
              />
              <span className="text-[11px] text-muted-foreground mt-1 inline-block">
                {isEn ? "Primary account email linked to PawCare ID" : "Email chính liên kết tài khoản PawCare"}
              </span>
            </div>

            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "Gender" : "Giới tính"}
              </label>
              <select
                value={profile.gender}
                onChange={(e) => setProfile({ ...profile, gender: e.target.value })}
                className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
              >
                <option value="male">{isEn ? "Male" : "Nam"}</option>
                <option value="female">{isEn ? "Female" : "Nữ"}</option>
                <option value="other">{isEn ? "Other / Prefer not to say" : "Khác / Không tiết lộ"}</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "Date of Birth" : "Ngày sinh"}
              </label>
              <input
                type="date"
                value={profile.birthDate}
                onChange={(e) => setProfile({ ...profile, birthDate: e.target.value })}
                className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "City / Contact Address" : "Tỉnh / Thành phố"}
              </label>
              <input
                value={profile.city}
                onChange={(e) => setProfile({ ...profile, city: e.target.value })}
                className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>

            <div className="sm:col-span-2 pt-2 flex justify-end">
              <button
                type="submit"
                className="rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow transition hover:opacity-90"
              >
                {isEn ? "Save Profile Changes" : "Lưu thay đổi hồ sơ"}
              </button>
            </div>
          </form>
        </Card>
      )}

      {/* TAB 2: Pet Information (Thông tin thú cưng) */}
      {activeTab === "pets" && (
        <Card className="p-6 md:p-8 space-y-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-border pb-4">
            <div>
              <h2 className="font-display text-xl font-bold flex items-center gap-2">
                <Heart className="size-5 text-rose-500" />
                <span>{isEn ? "Registered Pets" : "Danh sách thú cưng của tôi"}</span>
              </h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isEn
                  ? "Manage health records, microchips, and digital passports for your companions."
                  : "Quản lý y bạ, số vi mạch và hồ sơ theo dõi sức khỏe cho các bé cưng."}
              </p>
            </div>
            <Link
              href={`/${locale}/pet-health-setup`}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground shadow hover:opacity-90"
            >
              <Plus className="size-4" />
              <span>{isEn ? "Add New Pet" : "Thêm thú cưng mới"}</span>
            </Link>
          </div>

          {pets.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border p-8 text-center space-y-3 bg-muted/10">
              <div className="grid size-12 place-items-center rounded-2xl bg-secondary text-2xl mx-auto">
                🐾
              </div>
              <div>
                <h3 className="font-bold text-foreground text-sm">
                  {isEn ? "No pets registered yet" : "Chưa có thú cưng nào trong danh sách"}
                </h3>
                <p className="text-xs text-muted-foreground mt-1 max-w-sm mx-auto">
                  {isEn
                    ? "Add your companion to create their digital passport and track vaccinations."
                    : "Thêm thú cưng của bạn để bắt đầu tạo sổ y bạ điện tử và theo dõi lịch tiêm chủng."}
                </p>
              </div>
              <Link
                href={`/${locale}/pet-health-setup`}
                className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground shadow hover:opacity-90"
              >
                <Plus className="size-4" />
                <span>{isEn ? "Add First Pet" : "Thêm thú cưng đầu tiên"}</span>
              </Link>
            </div>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {pets.map((pet) => (
                <div
                  key={pet.id}
                  className="flex flex-col justify-between rounded-2xl border border-border bg-muted/20 p-5 transition hover:border-primary/40 hover:bg-muted/40"
                >
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="grid size-12 place-items-center rounded-2xl bg-secondary text-2xl shadow-inner">
                          {pet.species === "cat" ? "🐱" : "🐶"}
                        </div>
                        <div>
                          <h3 className="font-display text-lg font-bold">{pet.name}</h3>
                          <p className="text-xs text-muted-foreground">{pet.breed}</p>
                        </div>
                      </div>
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                        <Check className="size-3" />
                        {pet.status}
                      </span>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-2 text-xs">
                      <div className="rounded-xl bg-card p-2.5 border border-border/60">
                        <span className="text-muted-foreground block">{isEn ? "Weight" : "Cân nặng"}</span>
                        <strong className="text-foreground mt-0.5 block">{pet.weightKg} kg</strong>
                      </div>
                      <div className="rounded-xl bg-card p-2.5 border border-border/60">
                        <span className="text-muted-foreground block">{isEn ? "Microchip" : "Mã vi mạch"}</span>
                        <strong className="text-primary font-mono text-[11px] mt-0.5 block truncate">
                          {pet.microchip}
                        </strong>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-border flex items-center justify-between">
                    <span className="text-xs text-muted-foreground">
                      {isEn ? `${pet.vaxCount} vaccines recorded` : `Đã lưu ${pet.vaxCount} mũi tiêm`}
                    </span>
                    <Link
                      href={`/${locale}/owner/pets`}
                      className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline"
                    >
                      <span>{isEn ? "View Passport" : "Xem y bạ"}</span>
                      <span>→</span>
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* TAB 3: Change Password (Thay đổi mật khẩu) */}
      {activeTab === "password" && (
        <Card className="p-6 md:p-8 space-y-6">
          <div className="border-b border-border pb-4">
            <h2 className="font-display text-xl font-bold flex items-center gap-2">
              <Lock className="size-5 text-amber-500" />
              <span>{isEn ? "Change Account Password" : "Thay đổi mật khẩu tài khoản"}</span>
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {isEn
                ? "Protect your PawCare account with a strong, unique password."
                : "Bảo vệ tài khoản và y bạ thú cưng của bạn bằng mật khẩu an toàn và duy nhất."}
            </p>
          </div>

          {passwordError && (
            <div
              role="alert"
              className="flex items-center gap-2 rounded-xl border border-destructive/20 bg-destructive/10 p-3.5 text-xs font-semibold text-destructive"
            >
              <AlertCircle className="size-4 shrink-0" />
              <span>{passwordError}</span>
            </div>
          )}

          <form onSubmit={handlePasswordSubmit} className="space-y-4 max-w-md">
            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "Current Password" : "Mật khẩu hiện tại"}
              </label>
              <div className="relative mt-1">
                <input
                  type={showCurrentPassword ? "text" : "password"}
                  required
                  placeholder="••••••••"
                  value={passwords.current}
                  onChange={(e) => setPasswords({ ...passwords, current: e.target.value })}
                  className="w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                  className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
                >
                  {showCurrentPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "New Password" : "Mật khẩu mới"}
              </label>
              <div className="relative mt-1">
                <input
                  type={showNewPassword ? "text" : "password"}
                  required
                  minLength={8}
                  placeholder="••••••••"
                  value={passwords.newPassword}
                  onChange={(e) => setPasswords({ ...passwords, newPassword: e.target.value })}
                  className="w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-2.5 text-muted-foreground hover:text-foreground"
                >
                  {showNewPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1">
                {isEn ? "At least 8 characters with numbers & symbols" : "Ít nhất 8 ký tự bao gồm chữ và số"}
              </p>
            </div>

            <div>
              <label className="text-xs font-bold text-foreground">
                {isEn ? "Confirm New Password" : "Xác nhận mật khẩu mới"}
              </label>
              <input
                type="password"
                required
                minLength={8}
                placeholder="••••••••"
                value={passwords.confirmPassword}
                onChange={(e) => setPasswords({ ...passwords, confirmPassword: e.target.value })}
                className="mt-1 w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>

            <button
              type="submit"
              className="rounded-xl bg-primary px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow transition hover:opacity-90"
            >
              {isEn ? "Update Password" : "Cập nhật mật khẩu"}
            </button>
          </form>
        </Card>
      )}

      {/* TAB 4: Payment Methods (Phương thức thanh toán) */}
      {activeTab === "billing" && (
        <Card className="p-6 md:p-8 space-y-6">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between border-b border-border pb-4">
            <div>
              <h2 className="font-display text-xl font-bold flex items-center gap-2">
                <CreditCard className="size-5 text-emerald-500" />
                <span>{isEn ? "Payment Methods & CarePlan" : "Phương thức thanh toán & Gói dịch vụ"}</span>
              </h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isEn
                  ? "Manage payment methods for clinic booking deposits and subscription plans."
                  : "Quản lý thẻ, ví điện tử dùng để đặt lịch khám và gia hạn gói thành viên PawCare."}
              </p>
            </div>
            <Link
              href={`/${locale}/owner/billing`}
              className="inline-flex shrink-0 items-center gap-1.5 rounded-xl border border-border bg-card px-4 py-2 text-xs font-semibold hover:bg-muted"
            >
              <span>{isEn ? "Manage Subscription" : "Chi tiết gói dịch vụ"}</span>
              <ExternalLink className="size-3.5" />
            </Link>
          </div>

          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              {isEn ? "Linked Payment Cards & Wallets" : "Thẻ & Ví điện tử đã liên kết"}
            </h3>

            {paymentMethods.map((pm) => (
              <div
                key={pm.id}
                className="flex items-center justify-between rounded-2xl border border-border bg-card p-4 transition hover:border-primary/40"
              >
                <div className="flex items-center gap-3">
                  <div className="grid size-12 place-items-center rounded-xl bg-secondary text-primary font-bold text-sm">
                    {pm.type === "card" ? "💳" : "📱"}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-foreground text-sm">{pm.brand}</span>
                      {pm.isDefault && (
                        <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-bold text-primary">
                          {isEn ? "Default" : "Mặc định"}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {pm.last4 ? `•••• •••• •••• ${pm.last4} · Exp: ${pm.expiry}` : pm.account}
                    </p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    showToast(isEn ? "Payment method updated" : "Đã cập nhật phương thức thanh toán")
                  }
                  className="rounded-lg p-2 text-muted-foreground hover:bg-muted hover:text-destructive transition"
                  title={isEn ? "Remove payment method" : "Xóa phương thức thanh toán"}
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            ))}

            <button
              type="button"
              onClick={() =>
                showToast(isEn ? "Add payment modal opened" : "Mở hộp thoại thêm phương thức thanh toán")
              }
              className="w-full rounded-2xl border-2 border-dashed border-border p-3.5 text-center text-xs font-bold text-primary hover:border-primary/60 hover:bg-primary/5 transition flex items-center justify-center gap-2"
            >
              <Plus className="size-4" />
              <span>{isEn ? "Add New Credit/Debit Card or E-Wallet" : "Thêm thẻ ngân hàng hoặc Ví MoMo / ZaloPay mới"}</span>
            </button>
          </div>

          <div className="rounded-2xl border border-primary/20 bg-primary/5 p-4 flex items-center justify-between">
            <div className="space-y-0.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-primary">
                {isEn ? "Current Membership" : "Gói thành viên hiện tại"}
              </span>
              <p className="font-display font-bold text-foreground">PawCare Plus Member</p>
              <p className="text-xs text-muted-foreground">
                {isEn ? "Unlimited cloud passports & 10% clinic discounts" : "Y bạ đám mây không giới hạn & Giảm 10% tại phòng khám đối tác"}
              </p>
            </div>
            <Link
              href={`/${locale}/owner/billing`}
              className="rounded-xl bg-primary px-4 py-2 text-xs font-bold text-primary-foreground shadow hover:opacity-90 shrink-0"
            >
              {isEn ? "Upgrade" : "Nâng cấp"}
            </Link>
          </div>
        </Card>
      )}

      {/* TAB 5: Website Display Settings & Dark Theme (Cài đặt dành cho website) */}
      {activeTab === "display" && (
        <Card className="p-6 md:p-8 space-y-6">
          <div className="border-b border-border pb-4">
            <h2 className="font-display text-xl font-bold flex items-center gap-2">
              <Palette className="size-5 text-blue-500" />
              <span>{isEn ? "Website Display & Accessibility" : "Cài đặt hiển thị & Giao diện Website"}</span>
            </h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {isEn
                ? "Customize theme color, text size, and contrast mode for optimal comfort in any lighting."
                : "Tùy chỉnh giao diện sáng/tối, cỡ chữ và độ tương phản giúp mắt dễ nhìn nhất trong mọi điều kiện ánh sáng."}
            </p>
          </div>

          {/* 1. Theme Mode (Sáng / Tối) */}
          <div className="space-y-3">
            <div>
              <h3 className="font-bold text-sm text-foreground">
                {isEn ? "Color Theme (Dark / Light)" : "Chế độ giao diện (Sáng / Tối - Dark Mode)"}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isEn
                  ? "Dark theme reduces eye strain in low-light environments."
                  : "Theme đen giúp bảo vệ mắt khi sử dụng trong phòng tối hoặc điều kiện thiếu sáng."}
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => changeTheme("light")}
                className={`flex flex-col items-center justify-center gap-2.5 rounded-2xl border p-4 text-xs font-bold transition cursor-pointer ${
                  themeMode === "light"
                    ? "border-primary bg-primary/5 text-primary ring-2 ring-primary/20 shadow-xs"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                }`}
              >
                <div className="grid size-10 place-items-center rounded-xl bg-amber-500/10 text-amber-500">
                  <Sun className="size-5" />
                </div>
                <span>{isEn ? "Light Theme" : "Theme Sáng (Trắng)"}</span>
              </button>

              <button
                type="button"
                onClick={() => changeTheme("dark")}
                className={`flex flex-col items-center justify-center gap-2.5 rounded-2xl border p-4 text-xs font-bold transition cursor-pointer ${
                  themeMode === "dark"
                    ? "border-primary bg-primary/5 text-primary ring-2 ring-primary/20 shadow-xs"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                }`}
              >
                <div className="grid size-10 place-items-center rounded-xl bg-blue-500/10 text-blue-400">
                  <Moon className="size-5" />
                </div>
                <span>{isEn ? "Dark Theme" : "Theme Tối (Đen)"}</span>
              </button>

              <button
                type="button"
                onClick={() => changeTheme("system")}
                className={`flex flex-col items-center justify-center gap-2.5 rounded-2xl border p-4 text-xs font-bold transition cursor-pointer ${
                  themeMode === "system"
                    ? "border-primary bg-primary/5 text-primary ring-2 ring-primary/20 shadow-xs"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                }`}
              >
                <div className="grid size-10 place-items-center rounded-xl bg-muted text-foreground">
                  <Laptop className="size-5" />
                </div>
                <span>{isEn ? "System Auto" : "Tự động thiết bị"}</span>
              </button>
            </div>
          </div>

          {/* 2. Font Size (Cỡ chữ) */}
          <div className="space-y-3 pt-3 border-t border-border">
            <div>
              <h3 className="font-bold text-sm text-foreground">
                {isEn ? "Font Size Scaling" : "Cỡ chữ hiển thị website"}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isEn
                  ? "Scale text size across all dashboards and health passports."
                  : "Thay đổi kích cỡ chữ trên toàn bộ giao diện sổ y bạ và phòng khám."}
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {[
                { id: "sm", label: isEn ? "Small" : "Nhỏ", sample: "13.5px" },
                { id: "md", label: isEn ? "Default" : "Vừa (Chuẩn)", sample: "15px" },
                { id: "lg", label: isEn ? "Large" : "Lớn", sample: "17px" },
              ].map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => changeFontSize(f.id as any)}
                  className={`flex flex-col items-center justify-center gap-1 rounded-2xl border p-3.5 text-xs font-bold transition cursor-pointer ${
                    fontSize === f.id
                      ? "border-primary bg-primary/5 text-primary ring-2 ring-primary/20 shadow-xs"
                      : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                  }`}
                >
                  <span className={f.id === "sm" ? "text-xs" : f.id === "lg" ? "text-lg font-bold" : "text-sm font-semibold"}>
                    A
                  </span>
                  <span>{f.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Contrast Mode (Độ tương phản) */}
          <div className="space-y-3 pt-3 border-t border-border">
            <div>
              <h3 className="font-bold text-sm text-foreground">
                {isEn ? "Visual Contrast Mode" : "Độ tương phản (Contrast)"}
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {isEn
                  ? "Increase borders and text readability under bright sunlight or glare."
                  : "Tăng cường độ nổi bật của viền ô và chữ viết khi xem ngoài trời nắng hoặc mắt yếu."}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => changeContrast("normal")}
                className={`flex items-center justify-center gap-2 rounded-2xl border p-3.5 text-xs font-bold transition cursor-pointer ${
                  contrastMode === "normal"
                    ? "border-primary bg-primary/5 text-primary ring-2 ring-primary/20 shadow-xs"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                }`}
              >
                <span>{isEn ? "Standard Contrast" : "Tiêu chuẩn (Mặc định)"}</span>
              </button>

              <button
                type="button"
                onClick={() => changeContrast("high")}
                className={`flex items-center justify-center gap-2 rounded-2xl border p-3.5 text-xs font-bold transition cursor-pointer ${
                  contrastMode === "high"
                    ? "border-primary bg-primary/5 text-primary ring-2 ring-primary/20 shadow-xs"
                    : "border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground"
                }`}
              >
                <span>{isEn ? "High Contrast" : "Tương phản cao (High Contrast)"}</span>
              </button>
            </div>
          </div>
        </Card>
      )}

      {/* Account Sign Out / Delete Section */}
      <Card className="p-6 md:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-destructive/20 bg-destructive/5">
        <div>
          <h3 className="font-bold text-sm text-destructive">
            {isEn ? "Account Security & Session" : "Bảo mật phiên đăng nhập"}
          </h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {isEn
              ? "Sign out of your active session on this device."
              : "Đăng xuất tài khoản khỏi thiết bị hiện tại."}
          </p>
        </div>

        <form onSubmit={handleSignOut}>
          <button
            type="submit"
            disabled={isSigningOut}
            className="inline-flex items-center gap-2 rounded-xl bg-destructive px-5 py-2.5 text-xs font-bold text-destructive-foreground shadow hover:brightness-110 transition cursor-pointer disabled:opacity-60"
          >
            <LogOut className={`size-4 shrink-0 ${isSigningOut ? "animate-spin" : ""}`} />
            <span>
              {isSigningOut
                ? isEn
                  ? "Signing Out..."
                  : "Đang đăng xuất..."
                : isEn
                ? "Sign Out"
                : "Đăng xuất tài khoản"}
            </span>
          </button>
        </form>
      </Card>
    </div>
  );
}
